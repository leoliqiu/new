$ErrorActionPreference = "Stop"

$python = Get-Command py -ErrorAction SilentlyContinue
if ($python) {
    & py -3 (Join-Path $PSScriptRoot "app.py")
    exit $LASTEXITCODE
}

$python = Get-Command python -ErrorAction SilentlyContinue
if ($python) {
    & python (Join-Path $PSScriptRoot "app.py")
    exit $LASTEXITCODE
}

throw "Python 3 is not installed. Install it from https://www.python.org/downloads/windows/ and enable 'Add Python to PATH'."
