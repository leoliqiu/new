# VS Code Chat Desktop UI

A Python desktop chat window backed by VS Code's built-in GitHub Copilot chat
models. It does not use Codex.

## Setup

1. Open VS Code Chat and sign in to GitHub Copilot.
2. Install the PyQt6 UI dependency:

   ```powershell
   py -3 -m pip install PyQt6
   ```

3. Install the included local bridge:

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\install-extension.ps1
   ```

4. Fully restart VS Code, or run **Developer: Reload Window**.
5. Start the Python UI:

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\start-ui.ps1
   ```

The bridge starts automatically with VS Code and listens only on
`127.0.0.1` using a random bearer token.

## Important Limitation

VS Code does not provide a supported API for an external Python application to
invoke and capture the complete built-in Agent mode. This app uses VS Code's
public Language Model API and Copilot models, but it does not inherit Agent
mode's file editing, terminal, approval, or tool execution features.
