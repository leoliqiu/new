"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const { isAuthorized, validateChatRequest } = require("../bridge-core");

test("authorization accepts only the exact bearer token", () => {
  assert.equal(
    isAuthorized({ headers: { authorization: "Bearer secret" } }, "secret"),
    true
  );
  assert.equal(
    isAuthorized({ headers: { authorization: "Bearer wrong" } }, "secret"),
    false
  );
});

test("chat validation accepts a conversation", () => {
  assert.deepEqual(
    validateChatRequest({
      modelId: "model-a",
      messages: [
        { role: "user", content: "Hello" },
        { role: "assistant", content: "Hi" }
      ]
    }),
    {
      modelId: "model-a",
      messages: [
        { role: "user", content: "Hello" },
        { role: "assistant", content: "Hi" }
      ]
    }
  );
});

test("chat validation rejects unsupported roles", () => {
  assert.throws(
    () =>
      validateChatRequest({
        modelId: "model-a",
        messages: [{ role: "system", content: "Hello" }]
      }),
    /role must be user or assistant/
  );
});
