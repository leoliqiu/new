"use strict";

const crypto = require("crypto");
const fs = require("fs");
const http = require("http");
const os = require("os");
const path = require("path");
const vscode = require("vscode");
const {
  isAuthorized,
  readJsonBody,
  validateChatRequest,
  writeJson
} = require("./bridge-core");

const CONFIG_PATH = path.join(os.homedir(), ".vscode-ai-bridge.json");

let server;
let token;
let output;
let approvedModels = [];

async function discoverModels() {
  approvedModels = await vscode.lm.selectChatModels({ vendor: "copilot" });
  return approvedModels;
}

function modelInfo(model) {
  return {
    id: model.id,
    name: model.name || model.id,
    vendor: model.vendor,
    family: model.family,
    version: model.version,
    maxInputTokens: model.maxInputTokens
  };
}

function writeConnectionConfig(port, authToken) {
  fs.writeFileSync(
    CONFIG_PATH,
    `${JSON.stringify({ host: "127.0.0.1", port, token: authToken }, null, 2)}\n`,
    { encoding: "utf8", mode: 0o600 }
  );
}

async function sendChat(modelId, messages) {
  let model = approvedModels.find((item) => item.id === modelId);
  if (!model) {
    await discoverModels();
    model = approvedModels.find((item) => item.id === modelId);
  }
  if (!model) {
    throw Object.assign(new Error(`Model "${modelId}" is not currently available.`), {
      statusCode: 404
    });
  }

  const prompt = messages.map((message) =>
    message.role === "assistant"
      ? vscode.LanguageModelChatMessage.Assistant(message.content)
      : vscode.LanguageModelChatMessage.User(message.content)
  );
  const request = await model.sendRequest(
    prompt,
    {},
    new vscode.CancellationTokenSource().token
  );

  let text = "";
  for await (const fragment of request.text) {
    text += fragment;
  }
  return text;
}

async function handleRequest(request, response) {
  try {
    if (request.method === "GET" && request.url === "/health") {
      writeJson(response, 200, { ok: true, service: "vscode-ai-bridge" });
      return;
    }

    if (!isAuthorized(request, token)) {
      writeJson(response, 401, { error: "Unauthorized." });
      return;
    }

    if (request.method === "GET" && request.url === "/models") {
      const models = await discoverModels();
      writeJson(response, 200, { models: models.map(modelInfo) });
      return;
    }

    if (request.method === "POST" && request.url === "/chat") {
      const body = validateChatRequest(await readJsonBody(request));
      const text = await sendChat(body.modelId, body.messages);
      writeJson(response, 200, { text });
      return;
    }

    writeJson(response, 404, { error: "Not found." });
  } catch (error) {
    const statusCode = Number.isInteger(error.statusCode) ? error.statusCode : 500;
    output.appendLine(error.stack || String(error));
    writeJson(response, statusCode, {
      error: error.message || "The language model request failed."
    });
  }
}

async function startBridge(showMessage = true) {
  if (server) {
    if (showMessage) {
      vscode.window.showInformationMessage("VS Code Chat Bridge is already running.");
    }
    return;
  }

  const port = vscode.workspace
    .getConfiguration("vscodeAiBridge")
    .get("port", 32123);
  token = crypto.randomBytes(32).toString("hex");

  server = http.createServer((request, response) => {
    void handleRequest(request, response);
  });

  server.on("error", (error) => {
    output.appendLine(error.stack || String(error));
    vscode.window.showErrorMessage(`VS Code Chat Bridge failed: ${error.message}`);
    server = undefined;
  });

  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(port, "127.0.0.1", resolve);
  });

  writeConnectionConfig(port, token);
  try {
    await discoverModels();
  } catch (error) {
    output.appendLine(`Copilot model discovery is waiting for sign-in: ${error.message}`);
  }
  output.appendLine(`Listening at http://127.0.0.1:${port}`);
  if (showMessage) {
    vscode.window.showInformationMessage(
      `VS Code Chat Bridge started with ${approvedModels.length} Copilot model(s).`
    );
  }
}

async function stopBridge() {
  if (!server) {
    return;
  }
  await new Promise((resolve) => server.close(resolve));
  server = undefined;
  token = undefined;
  approvedModels = [];
  try {
    fs.unlinkSync(CONFIG_PATH);
  } catch (error) {
    if (error.code !== "ENOENT") {
      output.appendLine(error.stack || String(error));
    }
  }
  vscode.window.showInformationMessage("VS Code Chat Bridge stopped.");
}

function activate(context) {
  output = vscode.window.createOutputChannel("VS Code Chat Bridge");
  context.subscriptions.push(
    output,
    vscode.commands.registerCommand("vscodeAiBridge.start", () => startBridge(true)),
    vscode.commands.registerCommand("vscodeAiBridge.stop", stopBridge),
    { dispose: () => void stopBridge() }
  );
  void startBridge(false);
}

function deactivate() {
  return stopBridge();
}

module.exports = { activate, deactivate };
