# Source Precedence and Date Rules

## Purpose

Use this policy to determine what is current without confusing newer evidence with newer approved behavior.

## Date Fields

Record dates in ISO 8601:

- `created_at`: original creation date
- `updated_at`: last source edit date
- `effective_at`: date the instruction or requirement became valid
- `executed_at`: test execution date and time
- `retrieved_at`: date and time the source was collected
- `reviewed_at`: date a human or agent reviewed the content
- `generated_at`: date and time the Markdown was generated
- `superseded_at`: date an older item stopped being current

Prefer a timezone-qualified timestamp for events. Use a date only when the source provides no time.

If a historical date is unavailable, do not estimate it. Record:

```json
{
  "source_date": null,
  "date_status": "unknown",
  "retrieved_at": "2026-06-08T14:30:00-04:00"
}
```

## Authority Classes

Use this default order, highest first:

1. Approved requirement, contract, policy, or released specification
2. Approved product decision or authoritative Confluence page
3. Approved test strategy, workflow, or test case expectation
4. Defect resolution, release note, or implementation decision
5. qTest execution result, automated result, screenshot, or log
6. Draft page, analyst note, chat, or undocumented convention

Adapt the order only when the organization defines a different system of record.

## Supersedence Algorithm

For each claim:

1. Determine its subject, product scope, release, environment, and authority class.
2. Compare only claims that apply to the same subject and scope.
3. Within the same authority class, prefer the latest `effective_at`; otherwise use `updated_at`.
4. Mark older matching claims as superseded and link the replacing source.
5. Across authority classes, prefer the higher authority even when lower-authority evidence is newer.
6. Record a conflict when newer lower-authority evidence contradicts the approved expectation.
7. Replace the expectation only after a dated, approved source authorizes the new behavior.

## Evidence Interpretation

- A pass supports the tested expectation for the stated build, environment, and data.
- A fail shows a mismatch or execution problem; it does not by itself identify the correct behavior.
- A blocked or not-run result provides no behavioral confirmation.
- Repeated results strengthen confidence only when their scope and setup are comparable.
- A historical pass does not prove the current build.
- A newer result supersedes an older result for the same case/build scope, but both remain in history.

## Conflict Record

Record:

```markdown
### Conflict C-001

- Detected: 2026-06-08
- Subject: Password reset confirmation
- Approved expectation: Requirement REQ-42, effective 2026-05-01
- Contrary evidence: qTest run TR-918, executed 2026-06-07
- Current interpretation: Requirement remains normative; execution indicates a possible defect
- Resolution owner: Product owner
- Status: Open
```
