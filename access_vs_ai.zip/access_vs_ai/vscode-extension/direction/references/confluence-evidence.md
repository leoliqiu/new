# Confluence Evidence Handling

## Capture Page Identity

For every page used, record:

- space key and page ID
- title
- page version
- created and last-updated dates
- author or last editor when available
- approval state or lifecycle label
- retrieval date
- canonical URL

Use the page ID and version as identity. Titles and URLs can change.

## Select Current Content

1. Compare versions of the same page by version number and updated date.
2. Treat the latest approved version as current.
3. Mark earlier versions as superseded, retaining their version and dates.
4. Do not assume a newer draft supersedes an older approved version.
5. When two different pages conflict, apply the organization's ownership and authority rules; recency alone is insufficient.

## Extract Atomic Claims

Convert prose, tables, diagrams, and decision logs into atomic claims. Attach:

- source page ID and version
- source date
- section heading or anchor
- approval state
- applicable product, release, role, environment, or workflow stage

Keep quotations short. Paraphrase the behavior in application language while retaining the source link.

## Use qTest Results with Confluence

- Use execution results to confirm, challenge, or qualify a Confluence instruction.
- Add a dated learning note when execution reveals missing setup, unclear acceptance criteria, or a recurring failure mode.
- Do not edit an approved expectation solely to match a failing implementation.
- Link the resolving Confluence decision, requirement, defect, or release note when behavior changes.

## Rewrite Output

In the Markdown source register, identify Confluence evidence as:

```markdown
| CONF-01 / page 123456 v18 | Approved Confluence page | 2026-05-30 | 2026-06-08T13:00:00-04:00 | Current |
```
