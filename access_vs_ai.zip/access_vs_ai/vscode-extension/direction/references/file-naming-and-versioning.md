# File Naming and Versioning

## Purpose

Give every generated artifact a unique, searchable name while keeping the stable qTest or use-case ID visible.

## Naming Pattern

Use:

```text
<stable-id>-<short-title>-<review-date>.<extension>
```

Examples:

```text
tc-101-reset-password-2026-06-08.md
tc-101-reset-password-2026-06-08.json
workflow-authentication-rewrite-2026-06-08.md
```

Normalize names to lowercase ASCII letters, digits, and hyphens. Keep the stable source ID at the beginning. Use the document's `last_reviewed` date, not the source export date.

## Collision Handling

Never silently overwrite an existing generated artifact.

For another generation with the same ID, title, and date, append a numeric revision:

```text
tc-101-reset-password-2026-06-08-2.md
tc-101-reset-password-2026-06-08-3.md
```

The file suffix is storage history, not approval status. Record the actual change, source cutoff, and generation timestamp inside the file.

## Baselines and Current Copies

- Preserve raw exports with their original names.
- Store normalized JSON separately from generated Markdown.
- Do not rename source files in a way that removes qTest, requirement, defect, or Confluence IDs.
- Use repository history or an archive directory for obsolete generated files.
- Do not maintain an undated file named only `current.md` as the sole record.

## Suggested Directory Layout

```text
qa-documentation/
  raw/
  canonical/
  generated/
  archived/
```
