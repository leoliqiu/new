# Markdown Output Standard

## Document Template

```markdown
---
test_case_id: "TC-101"
title: "Reset a password with a valid email"
status: "active"
owner: "Quality Engineering"
last_reviewed: "2026-06-08"
generated_at: "2026-06-08T14:30:00-04:00"
source_cutoff: "2026-06-08T14:00:00-04:00"
---

# Reset a password with a valid email

> Current as of 2026-06-08. Older information is retained in Source Register and Change History.

## Use Case

- Actors: Registered user
- Goal: Regain access to the account
- Trigger: The user selects Forgot password
- Business value: Restore access without support intervention

## Traceability

- Requirements: REQ-42
- Risks: Unauthorized access; email delivery failure
- qTest case: TC-101

## Setup

- Environment: QA
- Build: 2026.06.08.1
- Preconditions: An active account exists
- Test data: `registered_user_email`

## Scenarios

### SC-01: Request a reset link

| # | Action | Expected result | Data | Evidence |
|---:|---|---|---|---|
| 1 | Select **Forgot password**. | The reset request form is displayed. | None | SRC-01 |

## Execution Evidence and Learning

| Evidence | Executed / source date | Build / environment | Result | Observation | Interpretation | Applies to |
|---|---|---|---|---|---|
| EV-01 / TR-918 | 2026-06-07T10:15:00-04:00 | 2026.06.07.2 / QA | Failed | Email was not received within five minutes. | regression-signal | SC-01 |

## Open Questions

- Q-01, opened 2026-06-08: What is the approved maximum email-delivery time?

## Source Register

| Source | Type | Version | Source date | Retrieved | Approval | Currency | Replaces |
|---|---|---|---|---|---|---|---|
| SRC-01 / REQ-42 | Requirement | 4 | 2026-05-01 | 2026-06-08T12:45:00-04:00 | Approved | Current | None |

## Superseded Content

| ID | Original section | Original source date | Status date | Replaced by | Reason |
|---|---|---|---|---|---|
| SUP-01 | Legacy delivery-time statement | 2025-11-03 | 2026-06-08 | Q-01 | The old time limit has no current approved source. |

## Change History

| Changed | Summary | Sources |
|---|---|---|
| 2026-06-08 | Rewrote qTest steps around the application use case. | SRC-01, EV-01 |
```

## Writing Rules

- Use imperative actions and observable expected results.
- Put one verifiable behavior in each step.
- Name UI controls exactly as the dated source names them.
- Use symbolic data names in backticks.
- State time limits, formats, states, messages, and side effects when approved sources define them.
- Avoid "verify that it works", "correctly", "as expected", and similar circular oracles.
- Keep evidence chronology outside active procedural steps.
- Use local relative links for repository documents and stable URLs for source systems.
- Add `Current as of` near the top so readers can assess currency immediately.
- Use the unique naming rules in [file-naming-and-versioning.md](file-naming-and-versioning.md).
