# Canonical QA Documentation Model

## Purpose

Normalize source data into a structured record before generating Markdown. JSON is the preferred interchange format because applications can validate, transform, search, and render it reliably.

## Record Shape

```json
{
  "document": {
    "test_case_id": "TC-101",
    "title": "Reset a password with a valid email",
    "status": "active",
    "owner": "Quality Engineering",
    "last_reviewed": "2026-06-08",
    "generated_at": "2026-06-08T14:30:00-04:00",
    "source_cutoff": "2026-06-08T14:00:00-04:00"
  },
  "use_case": {
    "actors": ["Registered user"],
    "goal": "Regain access to the account",
    "trigger": "The user selects Forgot password",
    "business_value": "Restore account access without support intervention"
  },
  "coverage": {
    "requirements": ["REQ-42"],
    "risks": ["Unauthorized account access", "Email delivery failure"],
    "tags": ["authentication", "regression"]
  },
  "setup": {
    "environment": "QA",
    "build": "2026.06.08.1",
    "preconditions": ["An active account exists for the test email"],
    "test_data": ["registered_user_email"]
  },
  "scenarios": [
    {
      "id": "SC-01",
      "title": "Request a reset link",
      "type": "happy-path",
      "priority": "high",
      "steps": [
        {
          "number": 1,
          "action": "Open the sign-in page and select Forgot password.",
          "expected": "The password-reset request form is displayed.",
          "data": null,
          "evidence_refs": ["SRC-01"]
        }
      ]
    }
  ],
  "evidence": [
    {
      "id": "EV-01",
      "kind": "qtest-execution",
      "source_id": "TR-918",
      "source_date": "2026-06-07T10:15:00-04:00",
      "date_status": "known",
      "retrieved_at": "2026-06-08T13:00:00-04:00",
      "result": "failed",
      "build": "2026.06.07.2",
      "environment": "QA",
      "summary": "Reset email was not received within five minutes.",
      "interpretation": "regression-signal",
      "url": null,
      "applies_to": ["SC-01"],
      "supersedes": ["EV-00"]
    }
  ],
  "sources": [
    {
      "id": "SRC-01",
      "kind": "requirement",
      "source_id": "REQ-42",
      "title": "Password reset",
      "version": "4",
      "approval_state": "approved",
      "source_date": "2026-05-01",
      "date_status": "known",
      "retrieved_at": "2026-06-08T12:45:00-04:00",
      "url": null,
      "authority": 1,
      "currency_status": "current",
      "supersedes": [],
      "superseded_at": null
    }
  ],
  "learning": [
    {
      "id": "LEARN-01",
      "observed_at": "2026-06-07T10:20:00-04:00",
      "statement": "Email delivery latency must be captured separately from UI confirmation.",
      "evidence_refs": ["EV-01"],
      "status": "proposed"
    }
  ],
  "open_questions": [
    {
      "id": "Q-01",
      "opened_at": "2026-06-08",
      "question": "What is the approved maximum email-delivery time?",
      "owner": "Product owner",
      "status": "open"
    }
  ],
  "change_log": [
    {
      "changed_at": "2026-06-08",
      "summary": "Rewrote qTest steps around the password-reset use case.",
      "source_refs": ["SRC-01", "EV-01"]
    }
  ],
  "superseded_content": [
    {
      "id": "SUP-01",
      "original_section": "Legacy delivery-time statement",
      "original_source_date": "2025-11-03",
      "status_date": "2026-06-08",
      "replaced_by": "Q-01",
      "reason": "The old time limit has no current approved source."
    }
  ]
}
```

## Modeling Rules

- Keep one canonical record per maintainable use case or test case.
- Use arrays for repeatable facts even when only one item currently exists.
- Use stable IDs for scenarios, evidence, learning, questions, and sources.
- Store source facts separately from rendered prose.
- Attach `evidence_refs` to the smallest practical unit, usually a step or learning item.
- Record build and environment on execution evidence; do not assume document-level setup applies to historical runs.
- Classify evidence interpretation as `confirmed`, `regression-signal`, `documentation-gap`, `environmental`, `test-design-gap`, or `proposed`.
- Record source currency as `current`, `superseded`, `conflicting`, `unsupported`, or `unknown`.
- For superseded sources, populate `superseded_at` and link the replacing IDs in `supersedes` or the supersedence map.
- Use `null` for absent optional values, not invented placeholders.
- Use `date_status: unknown` when `source_date` is `null`.
- Store secrets and personal data as symbolic test-data names, never literal credentials.
- Keep execution build and environment in `setup` or the individual evidence record.

## Recommended Pipeline

```text
Raw qTest / Confluence / MD / requirements
                 |
                 v
        Source inventory + dates
                 |
                 v
       Canonical JSON normalization
                 |
          validation/conflicts
                 |
                 v
      Markdown renderer or application API
```

Do not parse generated Markdown to recover structured data. Treat canonical JSON as the reusable application format and Markdown as a human-readable view.

Validate records intended for an application against [canonical-record.schema.json](canonical-record.schema.json) before rendering or ingestion.
