# Rewrite an Existing Test Document

## Objective

Produce a coherent current document from an older Markdown or Confluence-derived document while retaining dated traceability and superseded history.

## 1. Freeze and Date the Baseline

Record:

- document ID, path, or URL
- version or revision
- original created and updated dates
- retrieval date
- rewrite start date
- source cutoff date

Never overwrite the only copy of the baseline.

## 2. Build a Claim Ledger

Break the document into claims, instructions, expectations, and references. For each item record:

| Field | Meaning |
|---|---|
| Claim ID | Stable rewrite tracking ID |
| Section | Original location |
| Statement | Atomic meaning |
| Source date | Date supporting the statement |
| Authority | Requirement, approved page, test case, execution, or note |
| Status | Current, superseded, conflicting, unsupported, or unknown |
| Replacement | New source or claim ID |

Date the ledger review.

## 3. Classify Sections

Assign one action:

- `keep`: current, clear, and supported
- `update`: same intent, newer approved detail
- `replace`: structure or behavior is materially different
- `deprecate`: no longer current but historically relevant
- `add`: required information is missing

Do not retain wording merely because it is old and familiar.

## 4. Reconcile New Evidence

Use source precedence rules. A newer Confluence revision may supersede an older revision of the same approved page. A newer qTest execution supersedes an older result for the same scope, but it reinforces or challenges the documented expectation rather than automatically replacing it.

When resolution is unavailable, keep the approved expectation and add a dated conflict entry.

## 5. Rewrite Cleanly

Write a fresh current-state narrative:

- lead with the application use case
- consolidate repeated setup
- use action/expected-result step pairs
- move historical chronology to evidence and change-history sections
- remove obsolete instructions from the active flow
- preserve links and IDs
- label unsupported gaps

Avoid sentence-level patchwork that leaves contradictory eras in the same paragraph.

## 6. Produce a Supersedence Map

```markdown
## Superseded Content

| Original section | Original source date | Status date | Replaced by | Reason |
|---|---:|---:|---|---|
| 3.2 Legacy login | 2025-04-10 | 2026-06-08 | AUTH-DEC-17 | SSO became the approved login flow |
```

## 7. Produce a Dated Change Summary

State:

- what changed
- why it changed
- which sources authorized the change
- which execution evidence reinforced or challenged it
- which questions remain open

## 8. Review

Confirm that:

- current instructions contain no known superseded behavior
- historical content remains discoverable
- every substantive update has a dated source
- failures are not presented as requirements
- the rewrite is usable without reading the old document
- source IDs and links are intact
