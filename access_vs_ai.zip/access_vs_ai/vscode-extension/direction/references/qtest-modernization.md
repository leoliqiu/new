# qTest Modernization Guide

## Prefer Structured Inputs

Use qTest API JSON, XLSX, CSV, or XML exports before PDF or screenshots. Preserve column names, sheet names, row numbers, IDs, and export dates during extraction. When a workbook separates cases, steps, runs, and requirements, join them by stable IDs rather than names.

Use PDF, screenshots, and copied prose only as supporting evidence when structured data is unavailable. Mark OCR-derived or manually transcribed values as such.

## Extract

Capture, when available:

- project, module, test-case ID, name, version, status, priority, type, owner
- created and last-modified dates
- requirements and defects
- preconditions and description
- step number, action, expected result, and test data
- test cycle, test run, execution date, result, build, environment, executor, and attachments

Preserve the raw export. Record the extraction or retrieval time separately.

## Normalize Detailed Cases

1. Preserve the behavioral purpose and stable IDs.
2. Convert each step into one action and one observable expected result.
3. Split steps joined by "and" when separate outcomes can fail independently.
4. Replace vague expected results with measurable language only when a dated source supports the detail.
5. Move repeated setup to preconditions unless the setup behavior is itself under test.
6. Parameterize variable data such as users, dates, roles, and account states.
7. Group closely related cases under an application use case without merging distinct risk coverage.
8. Link every changed expectation to a dated source.

## Enrich Rudimentary Cases

Run a gap analysis for:

- actor and goal
- trigger
- initial state
- environment and build
- test data
- action sequence
- expected result or oracle
- negative and boundary behavior
- cleanup or state restoration
- requirement and risk coverage

Use authoritative dated sources to fill gaps. When support is absent:

```markdown
> Gap recorded 2026-06-08: The source does not define the maximum allowed processing time.
```

Do not turn common product patterns into facts. An inference can guide a question, not an approved expected result.

## Convert Execution Results into Reinforcement

For each relevant run, record:

- execution ID and date
- case version
- build and environment
- result
- concise observation
- evidence link
- related defect
- whether it supersedes an earlier execution

Then classify the learning:

- `confirmed`: evidence supports an approved expectation
- `regression-signal`: current behavior conflicts with a previously confirmed expectation
- `documentation-gap`: the oracle or procedure is unclear
- `environmental`: setup or dependency affected the run
- `test-design-gap`: the case could pass without proving the user goal
- `proposed`: useful lesson awaiting approval

Keep learning close to the affected scenario but do not clutter procedural steps with execution chronology.

## Improve Workflow-Level Documentation

For end-to-end workflows:

- define the business goal and participating roles
- show state transitions and system boundaries
- identify handoffs between UI, API, batch, email, or external systems
- define entry and exit criteria
- map each workflow stage to focused test scenarios
- distinguish workflow setup from assertions
- include recovery, retry, rollback, and cleanup paths where supported

Avoid one enormous test case that mixes many independent failures. Use a workflow overview plus linked focused cases.
