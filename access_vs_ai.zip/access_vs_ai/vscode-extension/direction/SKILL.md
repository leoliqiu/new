---
name: modernize-test-documentation
description: Modernize, rewrite, or generate dated Markdown test documentation from qTest exports, qTest execution results, existing Markdown, requirements, defects, and Confluence pages. Use when Codex must improve incomplete or inconsistent test cases, convert QA data into application use-case documentation, reinforce procedures with execution evidence and lessons learned, reconcile newer updates with older content, preserve source traceability, or rewrite an existing test workflow without losing audit history.
---

# Modernize Test Documentation

Convert mixed QA sources into clear, application-oriented Markdown while preserving dates, evidence, and traceability. Treat requirements as normative truth and test executions as empirical evidence.

## Choose the Workflow

- For qTest-derived cases or new Markdown, follow **Modernize Test Cases**.
- For a rewrite of an existing document, follow **Rewrite an Existing Document** and read [references/rewrite-existing-document.md](references/rewrite-existing-document.md).
- For both, normalize facts into the canonical model before drafting. Read [references/canonical-model.md](references/canonical-model.md).

## Apply Non-Negotiable Rules

1. Date every source, evidence item, decision, review, and generated document with ISO 8601 dates.
2. Never invent a historical date. Use `date_status: unknown` plus a dated retrieval record when the source date cannot be established.
3. Apply "newest wins" only to information with the same scope and authority. Preserve the older item as superseded history.
4. Do not let a newer failed execution silently redefine an approved requirement. Record it as evidence, learning, a defect signal, or a conflict.
5. Preserve stable IDs from qTest, requirements, defects, and Confluence.
6. Separate observed facts, approved expectations, inference, and unresolved questions.
7. Never invent missing steps, data, expected results, or product behavior. Mark gaps explicitly.
8. Write from the application user's point of view, not from the export's column layout.

Read [references/source-precedence.md](references/source-precedence.md) before resolving conflicts.

## Modernize Test Cases

### 1. Inventory Inputs

Identify each input and record:

- source type and stable ID
- title or filename
- source URL or path
- author or owner when known
- created, updated, effective, executed, and retrieved dates when available
- approval state
- product area, release, build, environment, and test cycle

Do not begin drafting until the evidence inventory exists.

### 2. Normalize Before Writing

Transform sources into the canonical JSON shape in [references/canonical-model.md](references/canonical-model.md). Use one record per application use case or independently maintainable test case.

Validate application-bound records against [references/canonical-record.schema.json](references/canonical-record.schema.json). Follow [references/file-naming-and-versioning.md](references/file-naming-and-versioning.md) for unique output names and revision handling.

Normalize:

- qTest test steps into action/expected-result pairs
- execution logs into dated evidence records
- Confluence statements into dated claims with page IDs and versions
- requirements and defects into traceability links
- repeated setup into preconditions
- environment-specific values into named test data or configuration

For Confluence evidence, read [references/confluence-evidence.md](references/confluence-evidence.md).

### 3. Assess Source Detail

For detailed qTest cases:

- preserve meaningful actions and expected results
- remove duplicate wording and UI narration that adds no verification value
- split compound steps when they have separate outcomes
- move repeated login, navigation, and setup into preconditions only when sequence is not under test
- retain qTest IDs and step-to-source traceability

For rudimentary qTest cases:

- preserve the stated intent
- identify missing actor, goal, trigger, preconditions, data, action, oracle, cleanup, and negative paths
- enrich only from dated authoritative sources
- label reasonable but unverified structure as `inference`
- add unresolved facts to `open_questions`; do not fill them with plausible guesses

Read [references/qtest-modernization.md](references/qtest-modernization.md) for detailed handling rules.

### 4. Resolve Currency and Conflicts

Group claims by subject and scope. Within each authority class, select the latest effective or updated item as current and mark older records as superseded.

When sources disagree across authority classes:

- retain the approved expectation as current
- attach newer execution evidence
- create a dated conflict or learning note
- link the defect or decision that resolves the conflict
- update the expectation only when a newer approved source authorizes the change

### 5. Organize Around Use Cases

Write each test case so a reader can answer:

- Who is acting?
- What goal are they trying to achieve?
- What triggers the flow?
- What state and data are required?
- What actions occur?
- What observable result proves success or failure?
- Which risks and requirements are covered?
- What did recent executions teach us?

Prefer one behavioral purpose per scenario. Separate happy path, validation, authorization, boundary, recovery, and regression scenarios when they have different oracles.

### 6. Draft Markdown

Follow [references/markdown-output-standard.md](references/markdown-output-standard.md). Include:

- dated metadata and source cutoff
- use-case summary
- requirements and risk traceability
- preconditions, environment, and test data
- numbered action/expected-result steps
- dated execution evidence and learning
- known gaps and open questions
- source register and change history

After normalization, optionally run:

```powershell
python scripts/render_test_cases.py canonical-record.json --output-dir generated
```

Use any available Python executable if `python` is not on `PATH`.

### 7. Perform Quality Review

Reject the draft if any answer is yes:

- Does an undated claim appear as current?
- Was behavior inferred from a failure without approval?
- Is an action missing an observable expected result?
- Can the test pass without proving the use-case goal?
- Are environment, data, or build details hidden in prose?
- Were IDs or source links dropped?
- Was old information deleted without a supersedence record?
- Are multiple behaviors bundled into an unmaintainable workflow?
- Is a vague term such as "works", "correct", or "successful" used without a measurable oracle?

## Rewrite an Existing Document

Do not incrementally paste updates into the old prose. Build a dated claim ledger, classify each section as keep, update, replace, deprecate, or add, and then produce a coherent clean rewrite.

Preserve:

- stable anchors and IDs when practical
- still-current intent and approved expectations
- useful historical evidence
- links needed for auditability

Change:

- stale steps superseded by newer approved information
- vague or non-verifiable expected results
- duplicated setup and contradictory guidance
- chronology presented as if it were current truth

Always include a dated change summary and a superseded-content map. Follow the full process in [references/rewrite-existing-document.md](references/rewrite-existing-document.md).

## Deliverables

Produce:

1. The current Markdown test document.
2. A dated source and evidence register.
3. A dated change summary or supersedence map for rewrites.
4. An open-questions list for unsupported gaps.
5. The canonical JSON record when repeatable rendering or application ingestion is needed.

Keep raw exports unchanged. Store normalized records and generated Markdown separately.
