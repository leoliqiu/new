#!/usr/bin/env python3
"""Render canonical QA JSON records as dated Markdown test documents."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any


DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}(?:T.*)?$")


def text(value: Any, default: str = "Not specified") -> str:
    if value is None or value == "":
        return default
    return str(value).replace("|", r"\|").replace("\n", " ")


def joined(values: Any, default: str = "None") -> str:
    if not values:
        return default
    return "; ".join(text(value) for value in values)


def slug(value: str) -> str:
    result = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return result or "test-case"


def check_date(value: Any, field: str, errors: list[str]) -> None:
    if value is not None and not DATE_RE.match(str(value)):
        errors.append(f"{field} must use ISO 8601: {value}")


def validate(record: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    document = record.get("document", {})
    for key in (
        "test_case_id",
        "title",
        "last_reviewed",
        "generated_at",
        "source_cutoff",
    ):
        if not document.get(key):
            errors.append(f"document.{key} is required")
    for key in ("last_reviewed", "generated_at", "source_cutoff"):
        check_date(document.get(key), f"document.{key}", errors)

    for collection in ("sources", "evidence"):
        for index, item in enumerate(record.get(collection, [])):
            source_date = item.get("source_date")
            date_status = item.get("date_status", "known")
            if source_date is None and date_status != "unknown":
                errors.append(
                    f"{collection}[{index}] needs source_date or date_status=unknown"
                )
            check_date(source_date, f"{collection}[{index}].source_date", errors)
            if not item.get("retrieved_at"):
                errors.append(f"{collection}[{index}].retrieved_at is required")
            check_date(
                item.get("retrieved_at"),
                f"{collection}[{index}].retrieved_at",
                errors,
            )
    dated_collections = (
        ("learning", "observed_at"),
        ("open_questions", "opened_at"),
        ("change_log", "changed_at"),
    )
    for collection, date_field in dated_collections:
        for index, item in enumerate(record.get(collection, [])):
            if not item.get(date_field):
                errors.append(f"{collection}[{index}].{date_field} is required")
            check_date(
                item.get(date_field),
                f"{collection}[{index}].{date_field}",
                errors,
            )
    return errors


def render(record: dict[str, Any]) -> str:
    doc = record["document"]
    use_case = record.get("use_case", {})
    coverage = record.get("coverage", {})
    setup = record.get("setup", {})
    lines: list[str] = [
        "---",
        f'test_case_id: "{text(doc.get("test_case_id"))}"',
        f'title: "{text(doc.get("title"))}"',
        f'status: "{text(doc.get("status"))}"',
        f'owner: "{text(doc.get("owner"))}"',
        f'last_reviewed: "{text(doc.get("last_reviewed"))}"',
        f'generated_at: "{text(doc.get("generated_at"))}"',
        f'source_cutoff: "{text(doc.get("source_cutoff"))}"',
        "---",
        "",
        f'# {text(doc.get("title"))}',
        "",
        f'> Current as of {text(doc.get("last_reviewed"))}.',
        "",
        "## Use Case",
        "",
        f'- Actors: {joined(use_case.get("actors"))}',
        f'- Goal: {text(use_case.get("goal"))}',
        f'- Trigger: {text(use_case.get("trigger"))}',
        f'- Business value: {text(use_case.get("business_value"))}',
        "",
        "## Traceability",
        "",
        f'- Requirements: {joined(coverage.get("requirements"))}',
        f'- Risks: {joined(coverage.get("risks"))}',
        f'- Tags: {joined(coverage.get("tags"))}',
        "",
        "## Setup",
        "",
        f'- Environment: {text(setup.get("environment"))}',
        f'- Build: {text(setup.get("build"))}',
        f'- Preconditions: {joined(setup.get("preconditions"))}',
        f'- Test data: {joined(setup.get("test_data"))}',
        "",
        "## Scenarios",
    ]

    for scenario in record.get("scenarios", []):
        lines.extend(
            [
                "",
                f'### {text(scenario.get("id"))}: {text(scenario.get("title"))}',
                "",
                f'- Type: {text(scenario.get("type"))}',
                f'- Priority: {text(scenario.get("priority"))}',
                "",
                "| # | Action | Expected result | Data | Evidence |",
                "|---:|---|---|---|---|",
            ]
        )
        for step in scenario.get("steps", []):
            lines.append(
                "| {number} | {action} | {expected} | {data} | {evidence} |".format(
                    number=text(step.get("number")),
                    action=text(step.get("action")),
                    expected=text(step.get("expected")),
                    data=text(step.get("data"), "None"),
                    evidence=joined(step.get("evidence_refs")),
                )
            )

    lines.extend(
        [
            "",
            "## Execution Evidence and Learning",
            "",
            "| Evidence | Executed / source date | Build / environment | Result | Observation | Applies to |",
            "|---|---|---|---|---|---|",
        ]
    )
    for item in record.get("evidence", []):
        source_date = item.get("source_date") or "Unknown"
        lines.append(
            f'| {text(item.get("id"))} / {text(item.get("source_id"))} '
            f'| {text(source_date)} '
            f'| {text(item.get("build"))} / {text(item.get("environment"))} '
            f'| {text(item.get("result"))} '
            f'| {text(item.get("summary"))} | {joined(item.get("applies_to"))} |'
        )
    for item in record.get("learning", []):
        lines.extend(
            [
                "",
                f'### {text(item.get("id"))}',
                "",
                f'- Observed: {text(item.get("observed_at"))}',
                f'- Status: {text(item.get("status"))}',
                f'- Learning: {text(item.get("statement"))}',
                f'- Evidence: {joined(item.get("evidence_refs"))}',
            ]
        )

    lines.extend(["", "## Open Questions", ""])
    questions = record.get("open_questions", [])
    if questions:
        for item in questions:
            lines.append(
                f'- {text(item.get("id"))}, opened {text(item.get("opened_at"))}: '
                f'{text(item.get("question"))} '
                f'(Owner: {text(item.get("owner"))}; Status: {text(item.get("status"))})'
            )
    else:
        lines.append("- None.")

    lines.extend(
        [
            "",
            "## Source Register",
            "",
            "| Source | Type | Version | Source date | Retrieved | Approval |",
            "|---|---|---|---|---|---|",
        ]
    )
    for item in record.get("sources", []):
        lines.append(
            f'| {text(item.get("id"))} / {text(item.get("source_id"))} '
            f'| {text(item.get("kind"))} | {text(item.get("version"))} '
            f'| {text(item.get("source_date"), "Unknown")} '
            f'| {text(item.get("retrieved_at"))} '
            f'| {text(item.get("approval_state"))} |'
        )

    lines.extend(
        [
            "",
            "## Change History",
            "",
            "| Changed | Summary | Sources |",
            "|---|---|---|",
        ]
    )
    for item in record.get("change_log", []):
        lines.append(
            f'| {text(item.get("changed_at"))} | {text(item.get("summary"))} '
            f'| {joined(item.get("source_refs"))} |'
        )
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="Canonical JSON file")
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    payload = json.loads(args.input.read_text(encoding="utf-8"))
    records = payload.get("test_cases", []) if isinstance(payload, dict) else []
    if not records and isinstance(payload, dict):
        records = [payload]
    if not records:
        raise SystemExit("Input must be a canonical record or contain test_cases.")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    failed = False
    for record in records:
        errors = validate(record)
        if errors:
            failed = True
            case_id = record.get("document", {}).get("test_case_id", "unknown")
            print(f"{case_id}:")
            for error in errors:
                print(f"  - {error}")
            continue
        document = record["document"]
        filename = f'{slug(document["test_case_id"])}-{slug(document["title"])}.md'
        output = args.output_dir / filename
        output.write_text(render(record), encoding="utf-8")
        print(output)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
