"""Desktop chat UI backed by VS Code's GitHub Copilot language models."""

from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request
from collections.abc import Callable
from pathlib import Path
from typing import Any

try:
    from PyQt6.QtCore import QEvent, QObject, QThread, QTimer, Qt, pyqtSignal, pyqtSlot
    from PyQt6.QtGui import QColor, QFont, QTextCharFormat, QTextCursor
    from PyQt6.QtWidgets import (
        QApplication,
        QComboBox,
        QFrame,
        QHBoxLayout,
        QLabel,
        QMainWindow,
        QMessageBox,
        QPushButton,
        QSizePolicy,
        QTextEdit,
        QVBoxLayout,
        QWidget,
    )
except ImportError as error:
    raise SystemExit(
        "PyQt6 is required to run this UI. Install it with: py -3 -m pip install PyQt6"
    ) from error


CONFIG_PATH = Path.home() / ".vscode-ai-bridge.json"
REQUEST_TIMEOUT_SECONDS = 300


class VSCodeChatClient:
    def _config(self) -> dict[str, object]:
        try:
            config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except FileNotFoundError as error:
            raise RuntimeError(
                "VS Code Chat Bridge is not running. Restart or reload VS Code, "
                "then click Refresh."
            ) from error
        except (OSError, json.JSONDecodeError) as error:
            raise RuntimeError(f"Could not read VS Code bridge settings: {error}") from error

        if not all(key in config for key in ("host", "port", "token")):
            raise RuntimeError("VS Code bridge settings are incomplete.")
        return config

    def request(
        self, method: str, path: str, body: dict[str, object] | None = None
    ) -> dict[str, object]:
        config = self._config()
        data = json.dumps(body).encode("utf-8") if body is not None else None
        request = urllib.request.Request(
            f"http://{config['host']}:{int(config['port'])}{path}",
            data=data,
            method=method,
            headers={
                "Authorization": f"Bearer {config['token']}",
                "Content-Type": "application/json",
            },
        )

        try:
            with urllib.request.urlopen(
                request, timeout=REQUEST_TIMEOUT_SECONDS
            ) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as error:
            try:
                detail = json.loads(error.read().decode("utf-8")).get("error")
            except (json.JSONDecodeError, UnicodeDecodeError):
                detail = None
            raise RuntimeError(detail or f"VS Code returned HTTP {error.code}.") from error
        except urllib.error.URLError as error:
            raise RuntimeError(
                "Could not connect to VS Code Chat Bridge. Reload VS Code and retry."
            ) from error

    def models(self) -> list[dict[str, object]]:
        response = self.request("GET", "/models")
        models = response.get("models", [])
        if not isinstance(models, list):
            raise RuntimeError("VS Code returned an invalid model list.")
        if not models:
            raise RuntimeError(
                "VS Code has no Copilot chat models available. Open VS Code Chat "
                "and sign in to GitHub Copilot first."
            )
        return models

    def chat(self, model_id: str, messages: list[dict[str, str]]) -> str:
        response = self.request(
            "POST", "/chat", {"modelId": model_id, "messages": messages}
        )
        text = response.get("text")
        if not isinstance(text, str) or not text.strip():
            raise RuntimeError("VS Code returned an empty response.")
        return text


class BackgroundWorker(QObject):
    result = pyqtSignal(str, object)
    error = pyqtSignal(str)
    finished = pyqtSignal()

    def __init__(
        self, name: str, function: Callable[..., object], *args: object
    ) -> None:
        super().__init__()
        self.name = name
        self.function = function
        self.args = args

    @pyqtSlot()
    def run(self) -> None:
        try:
            self.result.emit(self.name, self.function(*self.args))
        except Exception as error:
            self.error.emit(str(error))
        finally:
            self.finished.emit()


class ChatApp(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("VS Code Chat")
        self.resize(900, 680)
        self.setMinimumSize(650, 480)

        self.client = VSCodeChatClient()
        self.models_by_label: dict[str, dict[str, object]] = {}
        self.messages: list[dict[str, str]] = []
        self.busy = False
        self.direction_folder = Path(__file__).parent / "vscode-extension" / "direction"
        self.selected_file_content = ""
        self._threads: list[QThread] = []
        self._workers: list[BackgroundWorker] = []

        self._build_ui()
        QTimer.singleShot(200, self.refresh_models)
        QTimer.singleShot(250, self._refresh_skills)

    def _build_ui(self) -> None:
        central_widget = QWidget()
        root_layout = QVBoxLayout(central_widget)
        root_layout.setContentsMargins(10, 10, 10, 8)
        root_layout.setSpacing(8)
        self.setCentralWidget(central_widget)

        toolbar = QHBoxLayout()
        root_layout.addLayout(toolbar)

        toolbar.addWidget(QLabel("VS Code model:"))
        self.model_box = QComboBox()
        self.model_box.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed
        )
        toolbar.addWidget(self.model_box)

        self.refresh_button = QPushButton("Refresh")
        self.refresh_button.clicked.connect(self.refresh_models)
        toolbar.addWidget(self.refresh_button)

        self.new_chat_button = QPushButton("New chat")
        self.new_chat_button.clicked.connect(self.clear_chat)
        toolbar.addWidget(self.new_chat_button)

        skill_toolbar = QHBoxLayout()
        root_layout.addLayout(skill_toolbar)

        skill_toolbar.addWidget(QLabel("Skill/Prompt:"))
        self.skill_box = QComboBox()
        self.skill_box.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed
        )
        self.skill_box.currentIndexChanged.connect(self._load_skill_file)
        skill_toolbar.addWidget(self.skill_box)

        self.load_skill_button = QPushButton("Load")
        self.load_skill_button.clicked.connect(self._load_skill_file)
        skill_toolbar.addWidget(self.load_skill_button)

        self.refresh_skills_button = QPushButton("Refresh Files")
        self.refresh_skills_button.clicked.connect(self._refresh_skills)
        skill_toolbar.addWidget(self.refresh_skills_button)

        self.skill_status_label = QLabel("No skill selected")
        self.skill_status_label.setStyleSheet("color: gray;")
        skill_toolbar.addWidget(self.skill_status_label)

        self.transcript = QTextEdit()
        self.transcript.setReadOnly(True)
        self.transcript.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth)
        self.transcript.setFont(QFont("Segoe UI", 11))
        self.transcript.setFrameShape(QFrame.Shape.StyledPanel)
        root_layout.addWidget(self.transcript, stretch=1)

        input_layout = QHBoxLayout()
        root_layout.addLayout(input_layout)

        self.input_text = QTextEdit()
        self.input_text.setFixedHeight(115)
        self.input_text.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth)
        self.input_text.setFont(QFont("Segoe UI", 11))
        self.input_text.installEventFilter(self)
        input_layout.addWidget(self.input_text, stretch=1)

        self.send_button = QPushButton("Send\nCtrl+Enter")
        self.send_button.clicked.connect(self.send_message)
        input_layout.addWidget(self.send_button)

        self.status_label = QLabel("Connecting to VS Code Chat...")
        root_layout.addWidget(self.status_label)

    def _run_background(
        self, name: str, function: Callable[..., object], *args: object
    ) -> None:
        thread = QThread(self)
        worker = BackgroundWorker(name, function, *args)
        worker.moveToThread(thread)

        thread.started.connect(worker.run)
        worker.result.connect(self._handle_background_result)
        worker.error.connect(self._show_error)
        worker.finished.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(
            lambda thread=thread, worker=worker: self._remove_worker(thread, worker)
        )

        self._threads.append(thread)
        self._workers.append(worker)
        thread.start()

    def _remove_worker(self, thread: QThread, worker: BackgroundWorker) -> None:
        if thread in self._threads:
            self._threads.remove(thread)
        if worker in self._workers:
            self._workers.remove(worker)

    def _handle_background_result(self, event: str, payload: object) -> None:
        if event == "models":
            self._set_models(payload)
        elif event == "answer":
            self._show_answer(str(payload))

    def refresh_models(self) -> None:
        if self.busy:
            return
        self.status_label.setText("Loading VS Code models...")
        self.refresh_button.setEnabled(False)
        self._run_background("models", self.client.models)

    def _set_models(self, models: object) -> None:
        self.refresh_button.setEnabled(not self.busy)
        self.models_by_label = {}
        if not isinstance(models, list):
            self.status_label.setText("VS Code returned an invalid model list.")
            return

        for model in models:
            if not isinstance(model, dict):
                continue
            label = f"{model.get('name', model.get('id'))} [{model.get('family', 'model')}]"
            if label in self.models_by_label:
                label = f"{label} ({model.get('id')})"
            self.models_by_label[label] = model

        labels = list(self.models_by_label)
        self.model_box.clear()
        self.model_box.addItems(labels)
        if labels:
            self.model_box.setCurrentIndex(0)
        self.status_label.setText(f"VS Code Chat ready. {len(labels)} model(s) available.")

    def send_message(self) -> None:
        if self.busy:
            return
        prompt = self.input_text.toPlainText().strip()
        selected = self.models_by_label.get(self.model_box.currentText())
        if not prompt:
            return
        if not selected:
            QMessageBox.warning(self, "No model", "Refresh and select a model first.")
            return

        full_prompt = prompt
        if self.selected_file_content:
            full_prompt = f"{self.selected_file_content}\n\n{prompt}"

        self.input_text.clear()
        self.messages.append({"role": "user", "content": full_prompt})
        self._append_message("You", prompt, "user")
        self.busy = True
        self.send_button.setEnabled(False)
        self.refresh_button.setEnabled(False)
        self.status_label.setText("VS Code Chat is thinking...")
        self._run_background(
            "answer", self.client.chat, str(selected["id"]), list(self.messages)
        )

    def eventFilter(self, watched: QObject, event: Any) -> bool:
        if watched is self.input_text and event.type() == QEvent.Type.KeyPress:
            is_enter = event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter)
            has_control = bool(
                event.modifiers() & Qt.KeyboardModifier.ControlModifier
            )
            if is_enter and has_control:
                self.send_message()
                return True
        return super().eventFilter(watched, event)

    def _show_answer(self, text: str) -> None:
        self.messages.append({"role": "assistant", "content": text})
        self._append_message("VS Code Chat", text, "assistant")
        self._finish_request("Ready.")

    def _show_error(self, text: str) -> None:
        self._append_message("Error", text, "error")
        self._finish_request(text)

    def _finish_request(self, status: str) -> None:
        self.busy = False
        self.send_button.setEnabled(True)
        self.refresh_button.setEnabled(True)
        self.status_label.setText(status)
        self.input_text.setFocus()

    def _append_message(self, title: str, text: str, tag: str) -> None:
        title_format = QTextCharFormat()
        title_format.setFont(QFont("Segoe UI", 11, QFont.Weight.DemiBold))
        if tag == "user":
            title_format.setForeground(QColor("#1558a6"))
        elif tag == "assistant":
            title_format.setForeground(QColor("#176b3a"))
        else:
            title_format.setForeground(QColor("#b42318"))

        body_format = QTextCharFormat()
        body_format.setFont(QFont("Segoe UI", 11))

        cursor = self.transcript.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        cursor.insertText(f"{title}\n", title_format)
        cursor.insertText(f"{text}\n\n", body_format)
        self.transcript.setTextCursor(cursor)
        self.transcript.ensureCursorVisible()

    def clear_chat(self) -> None:
        if self.busy:
            return
        self.messages.clear()
        self.transcript.clear()
        self.status_label.setText("New chat.")

    def _refresh_skills(self) -> None:
        """Refresh the list of available skill/markdown files."""
        if not self.direction_folder.exists():
            self.skill_box.clear()
            self.skill_status_label.setText("Direction folder not found")
            return

        files = []
        try:
            for file in sorted(self.direction_folder.glob("*")):
                if file.is_file() and file.suffix in {".md", ".txt"}:
                    files.append(file.name)
        except Exception as error:
            self.skill_status_label.setText(f"Error reading folder: {error}")
            return

        self.skill_box.blockSignals(True)
        self.skill_box.clear()
        self.skill_box.addItems(files)
        self.skill_box.setCurrentIndex(-1)
        self.skill_box.blockSignals(False)

        if not files:
            self.skill_status_label.setText("No skill files found in direction folder")
        else:
            self.skill_status_label.setText(f"Found {len(files)} skill file(s)")

    def _load_skill_file(self, _index: int | bool | None = None) -> None:
        """Load the selected skill file content."""
        selected = self.skill_box.currentText()
        if not selected:
            self.skill_status_label.setText("No skill selected")
            return

        file_path = self.direction_folder / selected
        try:
            self.selected_file_content = file_path.read_text(encoding="utf-8")
            self.skill_status_label.setText(
                f"Loaded: {selected} ({len(self.selected_file_content)} chars)"
            )
        except Exception as error:
            self.skill_status_label.setText(f"Error loading file: {error}")
            self.selected_file_content = ""

    def closeEvent(self, event: Any) -> None:
        for thread in list(self._threads):
            thread.quit()
            thread.wait(1000)
        super().closeEvent(event)


def main() -> int:
    app = QApplication(sys.argv)
    window = ChatApp()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
