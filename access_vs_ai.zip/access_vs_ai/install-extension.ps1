$ErrorActionPreference = "Stop"

$source = Join-Path $PSScriptRoot "vscode-extension"
$destination = Join-Path $env:USERPROFILE ".vscode\extensions\local.vscode-ai-bridge-0.2.0"

if (-not (Test-Path $source)) {
    throw "Extension source was not found at $source"
}

New-Item -ItemType Directory -Force -Path $destination | Out-Null
Copy-Item -Path (Join-Path $source "*") -Destination $destination -Recurse -Force

Write-Host "Installed VS Code Chat Bridge to:"
Write-Host "  $destination"
Write-Host ""
Write-Host "Reload or restart VS Code. The VS Code Chat Bridge starts automatically."
Write-Host "You can also run this command from the Command Palette:"
Write-Host "  VS Code Chat Bridge: Start"
