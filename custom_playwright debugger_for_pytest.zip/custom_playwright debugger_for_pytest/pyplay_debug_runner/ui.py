from __future__ import annotations

from pathlib import Path

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFrame,
    QFormLayout,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSplitter,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from pyplay_debug_runner.models import DebugOptions, RunSummary, TestCase, TestResult
from pyplay_debug_runner.runner import DiscoveryWorker, RunWorker, open_trace_viewer
from pyplay_debug_runner.utils import open_path, parse_env_text


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("PyPlay Debug Runner")
        self.resize(1500, 920)

        self.tests: list[TestCase] = []
        self.results_by_nodeid: dict[str, TestResult] = {}
        self.last_summary: RunSummary | None = None
        self.discovery_worker: DiscoveryWorker | None = None
        self.run_worker: RunWorker | None = None
        self.current_run_dir: Path | None = None

        self.title_label = QLabel("PyPlay Debug Runner")
        self.subtitle_label = QLabel("Desktop runner for pytest + Playwright with traces, logs, and fast reruns.")
        self.project_root_input = QLineEdit(str(Path.cwd()))
        self.project_root_input.setPlaceholderText("Choose the pytest project root")
        self.project_root_input.setClearButtonEnabled(True)
        self.filter_input = QLineEdit()
        self.filter_input.setPlaceholderText("Filter by test name, file, or node id")
        self.filter_input.setClearButtonEnabled(True)
        self.headed_checkbox = QCheckBox("Headed")
        self.headed_checkbox.setChecked(True)
        self.inspector_checkbox = QCheckBox("Inspector Mode")
        self.pause_checkbox = QCheckBox("Pause On Failure")
        self.video_checkbox = QCheckBox("Record Video")
        self.console_checkbox = QCheckBox("Capture Console")
        self.console_checkbox.setChecked(True)
        self.browser_selector = QComboBox()
        self.browser_selector.addItem("Playwright Chromium", "playwright_chromium")
        self.browser_selector.addItem("Google Chrome", "google_chrome")
        self.browser_selector.addItem("Microsoft Edge", "microsoft_edge")
        self.browser_hint_label = QLabel(
            "Use the bundled Playwright Chromium, or launch the installed Google Chrome / Microsoft Edge stable channel."
        )
        self.slow_mo_input = QSpinBox()
        self.slow_mo_input.setRange(0, 5000)
        self.slow_mo_input.setSingleStep(50)
        self.slow_mo_input.setValue(250)
        self.slow_mo_input.setSuffix(" ms")
        self.slow_mo_input.setMinimumWidth(110)
        self.slow_mo_input.setAccelerated(True)
        self.slow_mo_decrease_button = QPushButton("-50 ms")
        self.slow_mo_increase_button = QPushButton("+50 ms")
        self.slow_mo_hint_label = QLabel(
            "Delay between Playwright actions. Use -/+ to change in 50 ms steps. "
            "Enable Inspector Mode for live stepping with Playwright Inspector."
        )
        self.env_input = QPlainTextEdit()
        self.env_input.setPlaceholderText("BASE_URL=https://example.test\nFEATURE_FLAG=true")
        self.browse_button = QPushButton("Browse")

        self.refresh_button = QPushButton("Refresh Tests")
        self.run_button = QPushButton("Run Selected")
        self.rerun_failed_button = QPushButton("Rerun Failed")
        self.stop_button = QPushButton("Stop")
        self.open_run_folder_button = QPushButton("Open Run Folder")
        self.select_all_button = QPushButton("Select All")
        self.clear_selection_button = QPushButton("Clear Selection")

        self.summary_label = QLabel("No tests loaded.")
        self.run_state_label = QLabel("Idle")
        self.run_path_label = QLabel("Artifacts will appear after the first run.")
        self.tests_count_value = QLabel("0")
        self.passed_count_value = QLabel("0")
        self.failed_count_value = QLabel("0")
        self.run_count_value = QLabel("Idle")
        self.tests_table = QTableWidget(0, 5)
        self.log_output = QTextEdit()
        self.result_label = QLabel("Outcome: -")
        self.duration_label = QLabel("Duration: -")
        self.message_output = QTextEdit()
        self.artifact_list = QListWidget()
        self.open_artifact_button = QPushButton("Open Artifact")
        self.open_trace_button = QPushButton("Open Trace Viewer")

        self._build_ui()
        self._apply_styles()
        self._connect_signals()
        self._sync_browser_target()
        self._set_run_state("Idle")
        self._update_dashboard()
        self.refresh_tests()

    def _build_ui(self) -> None:
        root = QWidget()
        root.setObjectName("appRoot")
        self.setCentralWidget(root)

        main_layout = QVBoxLayout(root)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(16)

        header_card, header_layout = self._create_card("heroCard")
        title_column = QVBoxLayout()
        title_column.setSpacing(4)
        self.title_label.setObjectName("titleLabel")
        self.subtitle_label.setObjectName("subtitleLabel")
        title_column.addWidget(self.title_label)
        title_column.addWidget(self.subtitle_label)

        run_summary_column = QVBoxLayout()
        run_summary_column.setSpacing(6)
        run_summary_column.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        run_state_caption = QLabel("Run State")
        run_state_caption.setProperty("muted", True)
        self.run_state_label.setObjectName("runStateLabel")
        self.run_path_label.setObjectName("runPathLabel")
        self.run_path_label.setWordWrap(True)
        self.run_path_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        run_summary_column.addWidget(run_state_caption, 0, Qt.AlignmentFlag.AlignRight)
        run_summary_column.addWidget(self.run_state_label, 0, Qt.AlignmentFlag.AlignRight)
        run_summary_column.addWidget(self.run_path_label, 0, Qt.AlignmentFlag.AlignRight)

        header_layout.addLayout(title_column, 1)
        header_layout.addLayout(run_summary_column)

        controls_row = QHBoxLayout()
        controls_row.setSpacing(16)

        project_card, project_layout = self._create_card("sectionCard")
        project_form = QGridLayout()
        project_form.setHorizontalSpacing(12)
        project_form.setVerticalSpacing(10)
        project_layout.addWidget(self._section_heading("Project"))
        project_form.addWidget(self._field_label("Project Root"), 0, 0)
        project_form.addWidget(self.project_root_input, 0, 1)
        project_form.addWidget(self.browse_button, 0, 2)
        project_form.addWidget(self._field_label("Filter"), 1, 0)
        project_form.addWidget(self.filter_input, 1, 1, 1, 2)
        project_layout.addLayout(project_form)

        options_card, options_layout = self._create_card("sectionCard")
        options_layout.addWidget(self._section_heading("Debug Options"))
        toggle_row = QHBoxLayout()
        toggle_row.setSpacing(12)
        for checkbox in (
            self.headed_checkbox,
            self.inspector_checkbox,
            self.pause_checkbox,
            self.video_checkbox,
            self.console_checkbox,
        ):
            toggle_row.addWidget(checkbox)
        toggle_row.addStretch(1)

        options_form = QGridLayout()
        options_form.setHorizontalSpacing(12)
        options_form.setVerticalSpacing(10)
        self.browser_hint_label.setProperty("fieldHelp", True)
        options_form.addWidget(self._field_label("Browser"), 0, 0)
        options_form.addWidget(self.browser_selector, 0, 1)
        options_form.addWidget(self.browser_hint_label, 1, 1)
        slow_mo_controls = QHBoxLayout()
        slow_mo_controls.setSpacing(8)
        slow_mo_controls.addWidget(self.slow_mo_decrease_button)
        slow_mo_controls.addWidget(self.slow_mo_input)
        slow_mo_controls.addWidget(self.slow_mo_increase_button)
        slow_mo_controls.addStretch(1)
        options_form.addWidget(self._field_label("Slow Mo Per Action"), 2, 0)
        options_form.addLayout(slow_mo_controls, 2, 1)
        self.slow_mo_hint_label.setProperty("fieldHelp", True)
        options_form.addWidget(self.slow_mo_hint_label, 3, 1)
        options_form.addWidget(self._field_label("Extra Env"), 4, 0, Qt.AlignmentFlag.AlignTop)
        options_form.addWidget(self.env_input, 4, 1)

        options_layout.addLayout(toggle_row)
        options_layout.addLayout(options_form)

        controls_row.addWidget(project_card, 3)
        controls_row.addWidget(options_card, 4)

        button_row = QHBoxLayout()
        button_row.setSpacing(10)
        for button in (
            self.refresh_button,
            self.run_button,
            self.rerun_failed_button,
            self.stop_button,
            self.open_run_folder_button,
            self.select_all_button,
            self.clear_selection_button,
        ):
            button_row.addWidget(button)
        button_row.addStretch(1)

        stats_row = QHBoxLayout()
        stats_row.setSpacing(12)
        stats_row.addWidget(self._create_stat_card("Tests", self.tests_count_value))
        stats_row.addWidget(self._create_stat_card("Passed", self.passed_count_value))
        stats_row.addWidget(self._create_stat_card("Failed", self.failed_count_value))
        stats_row.addWidget(self._create_stat_card("Current Run", self.run_count_value))

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(0)

        tests_card, tests_card_layout = self._create_card("paneCard")
        tests_header = QHBoxLayout()
        tests_header.setSpacing(12)
        tests_header.addWidget(self._section_heading("Test Explorer"))
        self.summary_label.setObjectName("summaryLabel")
        tests_header.addWidget(self.summary_label, 1)
        tests_card_layout.addLayout(tests_header)
        tests_card_layout.addWidget(self.tests_table)
        left_layout.addWidget(tests_card)

        right_splitter = QSplitter(Qt.Orientation.Vertical)
        right_splitter.setChildrenCollapsible(False)
        logs_panel = QWidget()
        logs_layout = QVBoxLayout(logs_panel)
        logs_layout.setContentsMargins(0, 0, 0, 0)
        logs_layout.setSpacing(0)

        logs_card, logs_card_layout = self._create_card("paneCard")
        logs_card_layout.addWidget(self._section_heading("Live Output"))
        logs_card_layout.addWidget(self.log_output)
        logs_layout.addWidget(logs_card)

        detail_panel = QWidget()
        detail_layout = QVBoxLayout(detail_panel)
        detail_layout.setContentsMargins(0, 0, 0, 0)
        detail_layout.setSpacing(0)
        detail_card, detail_card_layout = self._create_card("paneCard")
        detail_card_layout.addWidget(self._section_heading("Selected Result"))
        form = QFormLayout()
        form.setHorizontalSpacing(20)
        form.setVerticalSpacing(12)
        form.addRow("Result", self.result_label)
        form.addRow("Duration", self.duration_label)
        detail_card_layout.addLayout(form)
        notes_label = self._field_label("Failure / Notes")
        artifacts_label = self._field_label("Artifacts")
        detail_card_layout.addWidget(notes_label)
        detail_card_layout.addWidget(self.message_output)
        detail_card_layout.addWidget(artifacts_label)
        detail_card_layout.addWidget(self.artifact_list)
        detail_button_row = QHBoxLayout()
        detail_button_row.setSpacing(10)
        detail_button_row.addWidget(self.open_artifact_button)
        detail_button_row.addWidget(self.open_trace_button)
        detail_button_row.addStretch(1)
        detail_card_layout.addLayout(detail_button_row)
        detail_layout.addWidget(detail_card)

        right_splitter.addWidget(logs_panel)
        right_splitter.addWidget(detail_panel)
        splitter.addWidget(left_panel)
        splitter.addWidget(right_splitter)
        splitter.setSizes([780, 680])

        self.tests_table.setHorizontalHeaderLabels(["Run", "Status", "Node ID", "File", "Test"])
        self.tests_table.verticalHeader().setVisible(False)
        self.tests_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.tests_table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.tests_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.tests_table.setShowGrid(False)
        self.tests_table.setAlternatingRowColors(True)
        self.tests_table.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.tests_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.tests_table.setColumnWidth(0, 56)
        self.tests_table.setColumnWidth(1, 92)
        self.tests_table.setColumnWidth(2, 500)
        self.tests_table.setColumnWidth(3, 160)
        self.tests_table.horizontalHeader().setMinimumSectionSize(48)
        self.log_output.setReadOnly(True)
        self.log_output.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
        self.message_output.setReadOnly(True)
        self.message_output.setPlaceholderText("Failure details or notes for the selected test appear here.")
        self.artifact_list.setAlternatingRowColors(True)
        self.artifact_list.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.env_input.setFixedHeight(96)
        self.stop_button.setEnabled(False)
        self.rerun_failed_button.setEnabled(False)
        self.open_run_folder_button.setEnabled(False)
        self.open_artifact_button.setEnabled(False)
        self.open_trace_button.setEnabled(False)
        self.run_button.setProperty("variant", "primary")
        self.stop_button.setProperty("variant", "danger")
        self.run_state_label.setProperty("state", "idle")

        main_layout.addWidget(header_card)
        main_layout.addLayout(controls_row)
        main_layout.addLayout(button_row)
        main_layout.addLayout(stats_row)
        main_layout.addWidget(splitter, 1)

        self.browse_button.clicked.connect(self._choose_project_root)

    def _apply_styles(self) -> None:
        self.setStyleSheet(
            """
            QWidget#appRoot {
                background: #edf2f7;
                color: #102032;
            }
            QFrame[card="true"] {
                background: #ffffff;
                border: 1px solid #cfd8e3;
                border-radius: 18px;
            }
            QFrame[role="hero"] {
                background: qlineargradient(
                    x1: 0, y1: 0, x2: 1, y2: 1,
                    stop: 0 #0d2238, stop: 0.55 #133556, stop: 1 #1b4b71
                );
                border: 0;
            }
            QLabel {
                color: #102032;
            }
            QLabel[muted="true"] {
                color: #e4eef8;
                font-size: 11px;
                font-weight: 600;
                letter-spacing: 0.08em;
                text-transform: uppercase;
            }
            QLabel[sectionTitle="true"] {
                font-size: 16px;
                font-weight: 700;
                color: #10253f;
            }
            QLabel[fieldLabel="true"] {
                font-size: 12px;
                font-weight: 600;
                color: #43556e;
            }
            QLabel[fieldHelp="true"] {
                font-size: 12px;
                color: #51647c;
            }
            QLabel#titleLabel {
                color: #ffffff;
                font-size: 30px;
                font-weight: 800;
            }
            QLabel#subtitleLabel {
                color: #eef5fc;
                font-size: 13px;
            }
            QLabel#runStateLabel {
                color: #ffffff;
                font-size: 24px;
                font-weight: 800;
                padding: 4px 12px;
                border-radius: 999px;
                background: rgba(255, 255, 255, 0.2);
            }
            QLabel#runPathLabel {
                color: #f1f6fb;
                font-size: 12px;
            }
            QLabel#summaryLabel {
                color: #42546d;
                font-size: 12px;
                font-weight: 600;
            }
            QLabel[metricValue="true"] {
                font-size: 26px;
                font-weight: 800;
                color: #0d2238;
            }
            QLineEdit,
            QComboBox,
            QSpinBox,
            QTextEdit,
            QPlainTextEdit,
            QListWidget,
            QTableWidget {
                background: #ffffff;
                color: #102032;
                border: 1px solid #c7d2df;
                border-radius: 12px;
                padding: 8px 10px;
                selection-background-color: #cfe5ff;
                selection-color: #0d2238;
            }
            QLineEdit:focus,
            QComboBox:focus,
            QSpinBox:focus,
            QTextEdit:focus,
            QPlainTextEdit:focus,
            QListWidget:focus,
            QTableWidget:focus {
                border: 1px solid #2e73c9;
            }
            QLineEdit::placeholder,
            QTextEdit[placeholderText]:!focus,
            QPlainTextEdit[placeholderText]:!focus {
                color: #60728a;
            }
            QComboBox::drop-down {
                border: 0;
                width: 28px;
            }
            QComboBox::down-arrow {
                width: 10px;
                height: 10px;
            }
            QHeaderView::section {
                background: #e9eff6;
                color: #31445c;
                border: 0;
                border-bottom: 1px solid #c7d2df;
                padding: 10px 8px;
                font-size: 11px;
                font-weight: 700;
            }
            QTableWidget {
                gridline-color: transparent;
                alternate-background-color: #f4f7fb;
            }
            QListWidget {
                alternate-background-color: #f4f7fb;
            }
            QPushButton {
                background: #e6edf5;
                color: #102032;
                border: 1px solid #bcc8d7;
                border-radius: 12px;
                padding: 10px 16px;
                font-weight: 700;
            }
            QPushButton:hover {
                background: #dbe5f0;
            }
            QPushButton:pressed {
                background: #cfdae8;
            }
            QPushButton[variant="primary"] {
                background: #165fbe;
                color: #ffffff;
                border: 1px solid #165fbe;
            }
            QPushButton[variant="primary"]:hover {
                background: #114f9f;
            }
            QPushButton[variant="danger"] {
                background: #fdecea;
                color: #9f1f15;
                border: 1px solid #e7a9a2;
            }
            QPushButton:disabled,
            QCheckBox:disabled,
            QLineEdit:disabled,
            QTextEdit:disabled,
            QPlainTextEdit:disabled,
            QSpinBox:disabled {
                color: #6d7d92;
            }
            QCheckBox {
                spacing: 8px;
                font-weight: 600;
                color: #233750;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
                border-radius: 6px;
                border: 1px solid #97a8bc;
                background: #ffffff;
            }
            QCheckBox::indicator:checked {
                background: #165fbe;
                border: 1px solid #165fbe;
            }
            QSplitter::handle {
                background: transparent;
            }
            QScrollBar:vertical {
                background: transparent;
                width: 12px;
                margin: 10px 2px;
            }
            QScrollBar::handle:vertical {
                background: #aebdce;
                min-height: 30px;
                border-radius: 6px;
            }
            QScrollBar:horizontal {
                background: transparent;
                height: 12px;
                margin: 2px 10px;
            }
            QScrollBar::handle:horizontal {
                background: #aebdce;
                min-width: 30px;
                border-radius: 6px;
            }
            """
        )

    def _create_card(self, role: str) -> tuple[QFrame, QVBoxLayout]:
        card = QFrame()
        card.setProperty("card", True)
        card.setProperty("role", "hero" if role == "heroCard" else "default")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(14)
        return card, layout

    def _create_stat_card(self, title: str, value_label: QLabel) -> QFrame:
        card, layout = self._create_card("statCard")
        caption = QLabel(title)
        caption.setProperty("fieldLabel", True)
        value_label.setProperty("metricValue", True)
        layout.addWidget(caption)
        layout.addWidget(value_label)
        layout.addStretch(1)
        return card

    def _section_heading(self, text: str) -> QLabel:
        label = QLabel(text)
        label.setProperty("sectionTitle", True)
        return label

    def _field_label(self, text: str) -> QLabel:
        label = QLabel(text)
        label.setProperty("fieldLabel", True)
        return label

    def _connect_signals(self) -> None:
        self.refresh_button.clicked.connect(self.refresh_tests)
        self.run_button.clicked.connect(self.run_selected_tests)
        self.rerun_failed_button.clicked.connect(self.rerun_failed_tests)
        self.stop_button.clicked.connect(self.stop_run)
        self.open_run_folder_button.clicked.connect(self.open_run_folder)
        self.select_all_button.clicked.connect(lambda: self._set_all_rows_checked(True))
        self.clear_selection_button.clicked.connect(lambda: self._set_all_rows_checked(False))
        self.filter_input.textChanged.connect(self.apply_filter)
        self.tests_table.itemSelectionChanged.connect(self._update_detail_panel)
        self.tests_table.itemChanged.connect(self._on_table_item_changed)
        self.artifact_list.itemSelectionChanged.connect(self._update_artifact_buttons)
        self.open_artifact_button.clicked.connect(self.open_selected_artifact)
        self.open_trace_button.clicked.connect(self.open_selected_trace)
        self.slow_mo_decrease_button.clicked.connect(lambda: self._adjust_slow_mo(-50))
        self.slow_mo_increase_button.clicked.connect(lambda: self._adjust_slow_mo(50))
        self.inspector_checkbox.toggled.connect(self._sync_inspector_mode)
        self.browser_selector.currentIndexChanged.connect(lambda _: self._sync_browser_target())

    def _choose_project_root(self) -> None:
        selected = QFileDialog.getExistingDirectory(self, "Choose pytest project root", self.project_root_input.text())
        if selected:
            self.project_root_input.setText(selected)
            self.refresh_tests()

    def refresh_tests(self) -> None:
        if self.discovery_worker and self.discovery_worker.isRunning():
            return

        project_root = Path(self.project_root_input.text()).expanduser()
        if not project_root.exists():
            self._show_error(f"Project root does not exist: {project_root}")
            return

        self.summary_label.setText("Collecting tests...")
        self._set_run_state("Collecting")
        self.refresh_button.setEnabled(False)
        self.discovery_worker = DiscoveryWorker(project_root, parse_env_text(self.env_input.toPlainText()))
        self.discovery_worker.completed.connect(self._on_discovery_complete)
        self.discovery_worker.failed.connect(self._on_discovery_failed)
        self.discovery_worker.finished.connect(lambda: self.refresh_button.setEnabled(True))
        self.discovery_worker.start()

    def run_selected_tests(self) -> None:
        if self.run_worker and self.run_worker.isRunning():
            return

        selected_nodeids = self._selected_nodeids()
        if not selected_nodeids:
            self._show_error("Select at least one test to run.")
            return

        self._start_run(selected_nodeids)

    def rerun_failed_tests(self) -> None:
        if not self.last_summary or not self.last_summary.failed_nodeids:
            self._show_error("There are no failed tests to rerun.")
            return
        self._start_run(self.last_summary.failed_nodeids)

    def _start_run(self, nodeids: list[str]) -> None:
        project_root = Path(self.project_root_input.text()).expanduser()
        options = DebugOptions(
            headed=self.headed_checkbox.isChecked() or self.inspector_checkbox.isChecked(),
            inspector_mode=self.inspector_checkbox.isChecked(),
            browser_target=str(self.browser_selector.currentData()),
            slow_mo_ms=self.slow_mo_input.value(),
            record_video=self.video_checkbox.isChecked(),
            pause_on_failure=self.pause_checkbox.isChecked(),
            capture_console=self.console_checkbox.isChecked(),
            extra_env=parse_env_text(self.env_input.toPlainText()),
        )

        self.log_output.clear()
        self.result_label.setText("Outcome: -")
        self.duration_label.setText("Duration: -")
        self.message_output.clear()
        self.artifact_list.clear()
        self.last_summary = None
        self.results_by_nodeid.clear()
        self.open_artifact_button.setEnabled(False)
        self.open_trace_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.run_button.setEnabled(False)
        self.rerun_failed_button.setEnabled(False)
        self.refresh_button.setEnabled(False)
        self._set_run_state("Running")
        self.run_count_value.setText("Queued")

        for test in self.tests:
            if test.nodeid in nodeids:
                test.status = "Queued"
                test.message = ""
                test.duration = None
        self._populate_test_table()
        self._update_dashboard()

        self.run_worker = RunWorker(project_root, nodeids, options)
        self.run_worker.output.connect(self._append_log)
        self.run_worker.failed.connect(self._on_run_failed)
        self.run_worker.started_run.connect(self._on_run_started)
        self.run_worker.finished_summary.connect(self._on_run_complete)
        self.run_worker.finished.connect(self._reset_run_controls)
        self.run_worker.start()

    def stop_run(self) -> None:
        if self.run_worker:
            self.run_worker.stop()

    def open_run_folder(self) -> None:
        if self.current_run_dir and self.current_run_dir.exists():
            open_path(self.current_run_dir)

    def open_selected_artifact(self) -> None:
        item = self.artifact_list.currentItem()
        if not item:
            return
        artifact_path = item.data(Qt.ItemDataRole.UserRole)
        if artifact_path:
            open_path(Path(artifact_path))

    def open_selected_trace(self) -> None:
        result = self._selected_result()
        if not result or not result.trace_path:
            return
        try:
            open_trace_viewer(result.trace_path)
        except Exception as exc:
            self._show_error(str(exc))

    def apply_filter(self) -> None:
        needle = self.filter_input.text().strip().lower()
        for row in range(self.tests_table.rowCount()):
            nodeid_item = self.tests_table.item(row, 2)
            file_item = self.tests_table.item(row, 3)
            test_item = self.tests_table.item(row, 4)
            haystack = " ".join(
                filter(
                    None,
                    [
                        nodeid_item.text().lower() if nodeid_item else "",
                        file_item.text().lower() if file_item else "",
                        test_item.text().lower() if test_item else "",
                    ],
                )
            )
            self.tests_table.setRowHidden(row, bool(needle) and needle not in haystack)

    def _on_discovery_complete(self, tests: list[TestCase]) -> None:
        self.tests = tests
        self.results_by_nodeid.clear()
        self.last_summary = None
        self.current_run_dir = None
        self.run_count_value.setText("Ready")
        self._populate_test_table()
        self.summary_label.setText(f"Loaded {len(tests)} tests.")
        self.run_path_label.setText("Artifacts will appear after the first run.")
        self._set_run_state("Ready")
        self._update_dashboard()

    def _on_discovery_failed(self, message: str) -> None:
        self.summary_label.setText("Collection failed.")
        self.run_count_value.setText("Error")
        self._set_run_state("Error")
        self._show_error(message)

    def _on_run_started(self, run_dir: str) -> None:
        self.current_run_dir = Path(run_dir)
        self.open_run_folder_button.setEnabled(True)
        self.run_path_label.setText(run_dir)
        self.run_count_value.setText(Path(run_dir).name)
        self._append_log(f"Run folder: {run_dir}")

    def _on_run_complete(self, summary: RunSummary) -> None:
        self.last_summary = summary
        self.results_by_nodeid = {result.nodeid: result for result in summary.results}

        for test in self.tests:
            result = self.results_by_nodeid.get(test.nodeid)
            if not result:
                continue
            test.status = result.outcome.title()
            test.duration = result.duration
            test.message = result.message

        self._populate_test_table()
        self.summary_label.setText(
            f"Run {summary.run_id}: {summary.passed_count} passed, {summary.failed_count} failed, exit code {summary.exit_code}."
        )
        self.rerun_failed_button.setEnabled(bool(summary.failed_nodeids))
        self._set_run_state("Failed" if summary.failed_count else "Passed")
        self.run_path_label.setText(str(summary.run_dir))
        self.run_count_value.setText(summary.run_id)
        self._update_dashboard()
        self._update_detail_panel()

    def _on_run_failed(self, message: str) -> None:
        self._append_log(message)
        self.run_count_value.setText("Error")
        self._set_run_state("Error")
        self._show_error(message)

    def _reset_run_controls(self) -> None:
        self.stop_button.setEnabled(False)
        self.run_button.setEnabled(True)
        self.refresh_button.setEnabled(True)
        self._update_dashboard()

    def _append_log(self, message: str) -> None:
        self.log_output.append(message)

    def _populate_test_table(self) -> None:
        self.tests_table.blockSignals(True)
        self.tests_table.setRowCount(len(self.tests))
        for row, test in enumerate(self.tests):
            checkbox_item = QTableWidgetItem()
            checkbox_item.setFlags(
                Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsUserCheckable
            )
            checkbox_item.setCheckState(Qt.CheckState.Checked if test.selected else Qt.CheckState.Unchecked)
            checkbox_item.setData(Qt.ItemDataRole.UserRole, test.nodeid)
            self.tests_table.setItem(row, 0, checkbox_item)

            status_item = QTableWidgetItem(test.status)
            status_item.setForeground(self._status_color(test.status))
            nodeid_item = QTableWidgetItem(test.nodeid)
            path_item = QTableWidgetItem(Path(test.path).name if test.path else "")
            name_item = QTableWidgetItem(test.name)

            self.tests_table.setItem(row, 1, status_item)
            self.tests_table.setItem(row, 2, nodeid_item)
            self.tests_table.setItem(row, 3, path_item)
            self.tests_table.setItem(row, 4, name_item)
        self.tests_table.blockSignals(False)
        self.tests_table.resizeRowsToContents()
        self.apply_filter()
        self._update_dashboard()

    def _status_color(self, status: str) -> QColor:
        lowered = status.lower()
        if lowered == "passed":
            return QColor("#1b7f3b")
        if lowered == "failed":
            return QColor("#b42318")
        if lowered in {"queued", "running"}:
            return QColor("#9a6700")
        return QColor("#475467")

    def _selected_nodeids(self) -> list[str]:
        selected: list[str] = []
        for row in range(self.tests_table.rowCount()):
            item = self.tests_table.item(row, 0)
            if not item:
                continue
            checked = item.checkState() == Qt.CheckState.Checked
            nodeid = item.data(Qt.ItemDataRole.UserRole)
            if checked and nodeid:
                selected.append(str(nodeid))
                self._sync_test_selection(str(nodeid), True)
            elif nodeid:
                self._sync_test_selection(str(nodeid), False)
        return selected

    def _sync_test_selection(self, nodeid: str, selected: bool) -> None:
        for test in self.tests:
            if test.nodeid == nodeid:
                test.selected = selected
                return

    def _set_all_rows_checked(self, checked: bool) -> None:
        self.tests_table.blockSignals(True)
        for row in range(self.tests_table.rowCount()):
            item = self.tests_table.item(row, 0)
            if item:
                item.setCheckState(Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked)
        self.tests_table.blockSignals(False)
        for test in self.tests:
            test.selected = checked

    def _selected_result(self) -> TestResult | None:
        selected_rows = self.tests_table.selectionModel().selectedRows()
        if not selected_rows:
            return None
        nodeid_item = self.tests_table.item(selected_rows[0].row(), 2)
        if not nodeid_item:
            return None
        return self.results_by_nodeid.get(nodeid_item.text())

    def _update_detail_panel(self) -> None:
        result = self._selected_result()
        if not result:
            self.result_label.setText("Outcome: -")
            self.duration_label.setText("Duration: -")
            self.message_output.clear()
            self.artifact_list.clear()
            self.open_artifact_button.setEnabled(False)
            self.open_trace_button.setEnabled(False)
            return

        self.result_label.setText(result.outcome.title())
        duration = f"{result.duration:.2f}s" if result.duration is not None else "-"
        self.duration_label.setText(duration)
        self.message_output.setPlainText(result.message or "")

        self.artifact_list.clear()
        for label, artifact_path in (
            ("Trace", result.trace_path),
            ("Screenshot", result.screenshot_path),
            ("Console Log", result.console_log_path),
        ):
            if artifact_path:
                item = QListWidgetItem(f"{label}: {artifact_path.name}")
                item.setData(Qt.ItemDataRole.UserRole, str(artifact_path))
                self.artifact_list.addItem(item)
        for index, video_path in enumerate(result.video_paths, start=1):
            item = QListWidgetItem(f"Video {index}: {video_path.name}")
            item.setData(Qt.ItemDataRole.UserRole, str(video_path))
            self.artifact_list.addItem(item)

        self.open_trace_button.setEnabled(bool(result.trace_path))
        self._update_artifact_buttons()

    def _update_artifact_buttons(self) -> None:
        self.open_artifact_button.setEnabled(self.artifact_list.currentItem() is not None)

    def _on_table_item_changed(self, item: QTableWidgetItem) -> None:
        if item.column() != 0:
            return
        nodeid = item.data(Qt.ItemDataRole.UserRole)
        if nodeid:
            self._sync_test_selection(str(nodeid), item.checkState() == Qt.CheckState.Checked)

    def _update_dashboard(self) -> None:
        self.tests_count_value.setText(str(len(self.tests)))
        if self.last_summary:
            self.passed_count_value.setText(str(self.last_summary.passed_count))
            self.failed_count_value.setText(str(self.last_summary.failed_count))
            return

        passed = sum(1 for test in self.tests if test.status.lower() == "passed")
        failed = sum(1 for test in self.tests if test.status.lower() == "failed")
        queued = sum(1 for test in self.tests if test.status.lower() in {"queued", "running"})
        self.passed_count_value.setText(str(passed))
        self.failed_count_value.setText(str(failed))
        if queued:
            self.run_count_value.setText(f"{queued} queued")
        elif not self.tests:
            self.run_count_value.setText("Idle")

    def _set_run_state(self, state: str) -> None:
        palette = {
            "idle": ("Idle", "#dfe7f1", "#24384f"),
            "ready": ("Ready", "#d6e8ff", "#123f78"),
            "collecting": ("Collecting", "#ffe7b3", "#744700"),
            "running": ("Running", "#d7efe9", "#0c5d56"),
            "passed": ("Passed", "#d9efde", "#155f2d"),
            "failed": ("Failed", "#ffd9d5", "#8f1b13"),
            "error": ("Error", "#ffd9d5", "#8f1b13"),
        }
        key = state.strip().lower()
        label, background, foreground = palette.get(key, (state, "#dfe7f1", "#24384f"))
        self.run_state_label.setText(label)
        self.run_state_label.setStyleSheet(
            f"background: {background}; color: {foreground}; padding: 4px 12px; border-radius: 999px;"
        )

    def _adjust_slow_mo(self, delta: int) -> None:
        next_value = max(self.slow_mo_input.minimum(), min(self.slow_mo_input.maximum(), self.slow_mo_input.value() + delta))
        self.slow_mo_input.setValue(next_value)

    def _sync_inspector_mode(self, enabled: bool) -> None:
        if enabled:
            self.headed_checkbox.setChecked(True)
            self.headed_checkbox.setEnabled(False)
            self.pause_checkbox.setChecked(False)
            self.slow_mo_hint_label.setText(
                "Inspector Mode opens Playwright Inspector with PWDEBUG=1 and pauses at the start of the test. "
                "Use Resume or Step in Inspector. Slow Mo still applies between actions."
            )
            return

        self.headed_checkbox.setEnabled(True)
        self.slow_mo_hint_label.setText(
            "Delay between Playwright actions. Use -/+ to change in 50 ms steps. "
            "Enable Inspector Mode for live stepping with Playwright Inspector."
        )

    def _sync_browser_target(self) -> None:
        browser_target = str(self.browser_selector.currentData())
        if browser_target == "google_chrome":
            self.browser_hint_label.setText(
                "Launches the installed Google Chrome stable channel via Playwright's `--browser-channel chrome`."
            )
            return
        if browser_target == "microsoft_edge":
            self.browser_hint_label.setText(
                "Launches the installed Microsoft Edge stable channel via Playwright's `--browser-channel msedge`."
            )
            return
        self.browser_hint_label.setText(
            "Uses the bundled Playwright Chromium / Chrome for Testing browser managed by Playwright."
        )

    def _show_error(self, message: str) -> None:
        QMessageBox.critical(self, "PyPlay Debug Runner", message)


def run() -> int:
    app = QApplication.instance() or QApplication([])
    window = MainWindow()
    window.show()
    return app.exec()
