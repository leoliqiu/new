from __future__ import annotations

import json
import os
import traceback
from pathlib import Path
from typing import Any

import pytest


COLLECT_OUTPUT_ENV = "PYPLAY_COLLECT_OUTPUT"
RESULT_OUTPUT_ENV = "PYPLAY_RESULT_FILE"
ARTIFACT_ROOT_ENV = "PYPLAY_ARTIFACT_ROOT"
HEADLESS_ENV = "PYPLAY_HEADLESS"
SLOW_MO_ENV = "PYPLAY_SLOW_MO_MS"
VIDEO_ENV = "PYPLAY_RECORD_VIDEO"
CONSOLE_ENV = "PYPLAY_CAPTURE_CONSOLE"
PAUSE_ON_FAILURE_ENV = "PYPLAY_PAUSE_ON_FAILURE"
PAUSE_AT_START_ENV = "PYPLAY_PAUSE_AT_START"


def _flag(name: str, default: bool = False) -> bool:
    raw_value = os.getenv(name)
    if raw_value is None:
        return default
    return raw_value.strip().lower() in {"1", "true", "yes", "on"}


def _safe_int(name: str, default: int = 0) -> int:
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


def _slug(nodeid: str) -> str:
    cleaned = [character if character.isalnum() or character in "._-" else "_" for character in nodeid]
    slug = "".join(cleaned).strip("_")
    return slug or "test"


class DebugState:
    def __init__(self) -> None:
        self.collect_output = Path(os.getenv(COLLECT_OUTPUT_ENV, "")) if os.getenv(COLLECT_OUTPUT_ENV) else None
        self.result_output = Path(os.getenv(RESULT_OUTPUT_ENV, "")) if os.getenv(RESULT_OUTPUT_ENV) else None
        self.artifact_root = Path(os.getenv(ARTIFACT_ROOT_ENV, "")) if os.getenv(ARTIFACT_ROOT_ENV) else None
        self.record_video = _flag(VIDEO_ENV)
        self.capture_console = _flag(CONSOLE_ENV, True)
        self.pause_on_failure = _flag(PAUSE_ON_FAILURE_ENV)
        self.pause_at_start = _flag(PAUSE_AT_START_ENV)
        self.headless = _flag(HEADLESS_ENV, True)
        self.slow_mo_ms = _safe_int(SLOW_MO_ENV, 0)
        self.results: dict[str, dict[str, Any]] = {}

        if self.artifact_root:
            self.artifact_root.mkdir(parents=True, exist_ok=True)

    def ensure_result(self, nodeid: str) -> dict[str, Any]:
        result = self.results.get(nodeid)
        if result is None:
            artifact_dir = self.artifact_root / _slug(nodeid) if self.artifact_root else None
            if artifact_dir:
                artifact_dir.mkdir(parents=True, exist_ok=True)
            result = {
                "nodeid": nodeid,
                "outcome": "unknown",
                "duration": None,
                "artifact_dir": str(artifact_dir) if artifact_dir else "",
                "trace_path": "",
                "screenshot_path": "",
                "console_log_path": "",
                "video_paths": [],
                "message": "",
            }
            self.results[nodeid] = result
        return result

    def write_summary(self, exit_code: int) -> None:
        if not self.result_output:
            return
        payload = {
            "exit_code": exit_code,
            "results": list(self.results.values()),
        }
        self.result_output.write_text(json.dumps(payload, indent=2), encoding="utf-8")


STATE = DebugState()


@pytest.fixture(scope="session")
def browser_type_launch_args(browser_type_launch_args: dict[str, Any]) -> dict[str, Any]:
    args = dict(browser_type_launch_args)
    args["headless"] = STATE.headless
    if STATE.slow_mo_ms > 0:
        args["slow_mo"] = STATE.slow_mo_ms
    return args


@pytest.fixture
def browser_context_args(browser_context_args: dict[str, Any], request: pytest.FixtureRequest) -> dict[str, Any]:
    args = dict(browser_context_args)
    if not STATE.record_video:
        return args

    result = STATE.ensure_result(request.node.nodeid)
    artifact_dir = Path(result["artifact_dir"])
    video_dir = artifact_dir / "video"
    video_dir.mkdir(parents=True, exist_ok=True)
    args["record_video_dir"] = str(video_dir)
    return args


@pytest.fixture(autouse=True)
def _collect_debug_artifacts(request: pytest.FixtureRequest) -> None:
    result = STATE.ensure_result(request.node.nodeid)
    artifact_dir = Path(result["artifact_dir"]) if result["artifact_dir"] else None
    context = None
    page = None
    console_lines: list[str] = []

    def attach_page(target_page: Any) -> None:
        if getattr(target_page, "_pyplay_console_attached", False):
            return
        setattr(target_page, "_pyplay_console_attached", True)

        def on_console(message: Any) -> None:
            console_lines.append(f"[console:{message.type}] {message.text}")

        def on_page_error(error: Any) -> None:
            console_lines.append(f"[pageerror] {error}")

        target_page.on("console", on_console)
        target_page.on("pageerror", on_page_error)

    if "context" in request.fixturenames:
        try:
            context = request.getfixturevalue("context")
            if artifact_dir:
                trace_path = artifact_dir / "trace.zip"
                result["trace_path"] = str(trace_path)
            context.tracing.start(screenshots=True, snapshots=True, sources=True)
            if STATE.capture_console:
                for existing_page in context.pages:
                    attach_page(existing_page)
                context.on("page", attach_page)
        except Exception:
            console_lines.append(traceback.format_exc())

    if "page" in request.fixturenames:
        try:
            page = request.getfixturevalue("page")
            if STATE.capture_console:
                attach_page(page)
            if STATE.pause_at_start:
                STATE.pause_at_start = False
                page.pause()
        except Exception:
            console_lines.append(traceback.format_exc())

    yield

    setup_report = getattr(request.node, "_pyplay_setup_report", None)
    call_report = getattr(request.node, "_pyplay_call_report", None)
    teardown_report = getattr(request.node, "_pyplay_teardown_report", None)
    failed = any(report and report.failed for report in (setup_report, call_report, teardown_report))

    if page and failed and artifact_dir:
        screenshot_path = artifact_dir / "failure.png"
        try:
            page.screenshot(path=str(screenshot_path), full_page=True)
            result["screenshot_path"] = str(screenshot_path)
        except Exception:
            console_lines.append(traceback.format_exc())

    if context and artifact_dir:
        try:
            context.tracing.stop(path=result["trace_path"] or str(artifact_dir / "trace.zip"))
        except Exception:
            console_lines.append(traceback.format_exc())

    if STATE.capture_console and artifact_dir:
        console_log_path = artifact_dir / "console.log"
        console_log_path.write_text("\n".join(console_lines), encoding="utf-8")
        result["console_log_path"] = str(console_log_path)

    if failed and STATE.pause_on_failure and page:
        page.pause()


def pytest_collection_finish(session: pytest.Session) -> None:
    if not STATE.collect_output:
        return
    payload = {
        "tests": [
            {
                "nodeid": item.nodeid,
                "path": str(Path(str(item.fspath)).resolve()),
                "name": item.name,
                "lineno": item.location[1] + 1 if item.location else None,
            }
            for item in session.items
        ]
    }
    STATE.collect_output.write_text(json.dumps(payload, indent=2), encoding="utf-8")


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item: pytest.Item, call: pytest.CallInfo[Any]) -> None:
    outcome = yield
    report = outcome.get_result()
    setattr(item, f"_pyplay_{report.when}_report", report)

    result = STATE.ensure_result(item.nodeid)
    if report.when == "call":
        result["duration"] = report.duration
        result["outcome"] = "passed" if report.passed else "failed" if report.failed else "skipped"
        if report.failed:
            result["message"] = str(report.longrepr)
    elif report.when == "setup" and report.failed:
        result["outcome"] = "failed"
        result["message"] = str(report.longrepr)
    elif report.when == "teardown":
        if report.failed:
            result["outcome"] = "failed"
            result["message"] = str(report.longrepr)


def pytest_runtest_logreport(report: pytest.TestReport) -> None:
    if report.when != "teardown":
        return
    result = STATE.ensure_result(report.nodeid)
    artifact_dir = Path(result["artifact_dir"]) if result["artifact_dir"] else None
    if not artifact_dir or not artifact_dir.exists():
        return
    if STATE.record_video:
        result["video_paths"] = [str(path) for path in artifact_dir.rglob("*.webm")]
    if result["outcome"] == "unknown":
        result["outcome"] = "passed" if report.passed else "failed" if report.failed else "skipped"


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:
    STATE.write_summary(exitstatus)
