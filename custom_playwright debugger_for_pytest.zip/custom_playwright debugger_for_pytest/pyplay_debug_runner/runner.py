from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import threading
from pathlib import Path

from PyQt6.QtCore import QThread, pyqtSignal

from pyplay_debug_runner.models import DebugOptions, RunSummary, TestCase, TestResult
from pyplay_debug_runner.utils import APP_ROOT, ensure_dir, make_run_id


COLLECT_OUTPUT_ENV = "PYPLAY_COLLECT_OUTPUT"
RESULT_OUTPUT_ENV = "PYPLAY_RESULT_FILE"
ARTIFACT_ROOT_ENV = "PYPLAY_ARTIFACT_ROOT"
HEADLESS_ENV = "PYPLAY_HEADLESS"
SLOW_MO_ENV = "PYPLAY_SLOW_MO_MS"
VIDEO_ENV = "PYPLAY_RECORD_VIDEO"
CONSOLE_ENV = "PYPLAY_CAPTURE_CONSOLE"
PAUSE_ON_FAILURE_ENV = "PYPLAY_PAUSE_ON_FAILURE"
PWDEBUG_ENV = "PWDEBUG"
PAUSE_AT_START_ENV = "PYPLAY_PAUSE_AT_START"


def discover_tests(project_root: Path, extra_env: dict[str, str] | None = None) -> list[TestCase]:
    fd, output_path_text = tempfile.mkstemp(prefix="pyplay-collect-", suffix=".json")
    os.close(fd)
    output_path = Path(output_path_text)
    env = build_env(project_root, extra_env or {})
    env[COLLECT_OUTPUT_ENV] = str(output_path)
    command = [sys.executable, "-m", "pytest", "--collect-only", "-q", "-p", "pyplay_debug_runner.pytest_plugin"]
    completed = subprocess.run(
        command,
        cwd=project_root,
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )
    if not output_path.exists():
        stderr = completed.stderr.strip()
        stdout = completed.stdout.strip()
        detail = stderr or stdout or "pytest collection did not produce any output."
        raise RuntimeError(detail)

    try:
        payload = json.loads(output_path.read_text(encoding="utf-8"))
    finally:
        output_path.unlink(missing_ok=True)

    items = payload.get("tests", [])
    if not isinstance(items, list):
        raise RuntimeError("Invalid collection response from pytest.")

    return [
        TestCase(
            nodeid=str(item.get("nodeid", "")),
            path=str(item.get("path", "")),
            name=str(item.get("name", "")),
            lineno=item.get("lineno") if isinstance(item.get("lineno"), int) else None,
            selected=False,
        )
        for item in items
        if item.get("nodeid")
    ]


def build_env(project_root: Path, extra_env: dict[str, str]) -> dict[str, str]:
    env = os.environ.copy()
    env.update(extra_env)
    existing_python_path = env.get("PYTHONPATH", "")
    python_path_parts = [str(APP_ROOT)]
    if existing_python_path:
        python_path_parts.append(existing_python_path)
    env["PYTHONPATH"] = os.pathsep.join(python_path_parts)
    env["PYTHONUNBUFFERED"] = "1"
    env["PYPLAY_PROJECT_ROOT"] = str(project_root)
    return env


def build_run_summary(run_id: str, project_root: Path, run_dir: Path, exit_code: int) -> RunSummary:
    result_path = run_dir / "run_summary.json"
    if result_path.exists():
        payload = json.loads(result_path.read_text(encoding="utf-8"))
        results = [TestResult.from_dict(item) for item in payload.get("results", [])]
        return RunSummary(
            run_id=run_id,
            project_root=project_root,
            run_dir=run_dir,
            exit_code=payload.get("exit_code", exit_code) if isinstance(payload.get("exit_code"), int) else exit_code,
            results=results,
        )
    return RunSummary(run_id=run_id, project_root=project_root, run_dir=run_dir, exit_code=exit_code, results=[])


def build_browser_args(browser_target: str) -> list[str]:
    mapping = {
        "playwright_chromium": ["--browser", "chromium"],
        "google_chrome": ["--browser", "chromium", "--browser-channel", "chrome"],
        "microsoft_edge": ["--browser", "chromium", "--browser-channel", "msedge"],
    }
    return mapping.get(browser_target, mapping["playwright_chromium"])


class DiscoveryWorker(QThread):
    completed = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, project_root: Path, extra_env: dict[str, str] | None = None) -> None:
        super().__init__()
        self.project_root = project_root
        self.extra_env = extra_env or {}

    def run(self) -> None:
        try:
            tests = discover_tests(self.project_root, self.extra_env)
        except Exception as exc:  # pragma: no cover - UI error path
            self.failed.emit(str(exc))
            return
        self.completed.emit(tests)


class RunWorker(QThread):
    output = pyqtSignal(str)
    failed = pyqtSignal(str)
    started_run = pyqtSignal(str)
    finished_summary = pyqtSignal(object)

    def __init__(self, project_root: Path, nodeids: list[str], options: DebugOptions) -> None:
        super().__init__()
        self.project_root = project_root
        self.nodeids = nodeids
        self.options = options
        self._process: subprocess.Popen[str] | None = None

    def stop(self) -> None:
        if self._process and self._process.poll() is None:
            self._process.terminate()

    def run(self) -> None:
        run_id = make_run_id()
        run_dir = ensure_dir(self.project_root / ".pyplay-debug-runs" / run_id)
        env = build_env(self.project_root, self.options.extra_env)
        env[RESULT_OUTPUT_ENV] = str(run_dir / "run_summary.json")
        env[ARTIFACT_ROOT_ENV] = str(run_dir / "artifacts")
        env[HEADLESS_ENV] = "0" if (self.options.headed or self.options.inspector_mode) else "1"
        env[SLOW_MO_ENV] = str(self.options.slow_mo_ms)
        env[VIDEO_ENV] = "1" if self.options.record_video else "0"
        env[CONSOLE_ENV] = "1" if self.options.capture_console else "0"
        env[PAUSE_ON_FAILURE_ENV] = "1" if self.options.pause_on_failure else "0"
        if self.options.inspector_mode:
            env[PWDEBUG_ENV] = "1"
            env[PAUSE_AT_START_ENV] = "1"

        browser_args = build_browser_args(self.options.browser_target)
        command = [
            sys.executable,
            "-m",
            "pytest",
            "-s",
            "-vv",
            "-p",
            "pyplay_debug_runner.pytest_plugin",
            *browser_args,
            *self.nodeids,
        ]
        self.started_run.emit(str(run_dir))

        try:
            self._process = subprocess.Popen(
                command,
                cwd=self.project_root,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
            )
        except Exception as exc:  # pragma: no cover - UI error path
            self.failed.emit(str(exc))
            return

        stdout_thread = threading.Thread(target=self._stream_output, args=(self._process.stdout,))
        stderr_thread = threading.Thread(target=self._stream_output, args=(self._process.stderr,))
        stdout_thread.start()
        stderr_thread.start()
        exit_code = self._process.wait()
        stdout_thread.join()
        stderr_thread.join()

        summary = build_run_summary(run_id, self.project_root, run_dir, exit_code)
        self.finished_summary.emit(summary)

    def _stream_output(self, stream: object) -> None:
        if stream is None:
            return
        for line in stream:
            self.output.emit(line.rstrip())


def open_trace_viewer(trace_path: Path) -> subprocess.Popen[str]:
    return subprocess.Popen([sys.executable, "-m", "playwright", "show-trace", str(trace_path)])
