from __future__ import annotations

import os
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path


APP_ROOT = Path(__file__).resolve().parent.parent


def make_run_id() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def sanitize_nodeid(nodeid: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", nodeid).strip("_") or "test"


def parse_env_text(raw_text: str) -> dict[str, str]:
    env: dict[str, str] = {}
    for line in raw_text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        key = key.strip()
        if key:
            env[key] = value.strip()
    return env


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def open_path(path: Path) -> None:
    if sys.platform.startswith("win"):
        os.startfile(path)  # type: ignore[attr-defined]
        return
    if sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
        return
    subprocess.Popen(["xdg-open", str(path)])
