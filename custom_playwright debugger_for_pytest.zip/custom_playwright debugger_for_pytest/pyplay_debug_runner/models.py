from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class TestCase:
    nodeid: str
    path: str
    name: str
    lineno: int | None = None
    selected: bool = False
    status: str = "Idle"
    duration: float | None = None
    message: str = ""


@dataclass(slots=True)
class DebugOptions:
    headed: bool = True
    inspector_mode: bool = False
    browser_target: str = "playwright_chromium"
    slow_mo_ms: int = 250
    record_video: bool = False
    pause_on_failure: bool = False
    capture_console: bool = True
    extra_env: dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class TestResult:
    nodeid: str
    outcome: str
    duration: float | None = None
    artifact_dir: Path | None = None
    trace_path: Path | None = None
    screenshot_path: Path | None = None
    console_log_path: Path | None = None
    video_paths: list[Path] = field(default_factory=list)
    message: str = ""

    @classmethod
    def from_dict(cls, payload: dict[str, object]) -> "TestResult":
        return cls(
            nodeid=str(payload.get("nodeid", "")),
            outcome=str(payload.get("outcome", "unknown")),
            duration=payload.get("duration") if isinstance(payload.get("duration"), (int, float)) else None,
            artifact_dir=_path_or_none(payload.get("artifact_dir")),
            trace_path=_path_or_none(payload.get("trace_path")),
            screenshot_path=_path_or_none(payload.get("screenshot_path")),
            console_log_path=_path_or_none(payload.get("console_log_path")),
            video_paths=[Path(value) for value in payload.get("video_paths", []) if value],
            message=str(payload.get("message", "")),
        )


@dataclass(slots=True)
class RunSummary:
    run_id: str
    project_root: Path
    run_dir: Path
    exit_code: int
    results: list[TestResult] = field(default_factory=list)

    @property
    def failed_nodeids(self) -> list[str]:
        return [result.nodeid for result in self.results if result.outcome.lower() == "failed"]

    @property
    def passed_count(self) -> int:
        return sum(1 for result in self.results if result.outcome.lower() == "passed")

    @property
    def failed_count(self) -> int:
        return sum(1 for result in self.results if result.outcome.lower() == "failed")


def _path_or_none(value: object) -> Path | None:
    if isinstance(value, str) and value:
        return Path(value)
    return None
