# PyPlay Debug Runner

PyPlay Debug Runner is a desktop test runner for existing `pytest` + Playwright suites. It discovers tests, lets you run a selected subset with debug-friendly settings, and exposes traces, screenshots, video, and console logs from a PyQt6 UI.

## Install

```powershell
py -m pip install -r requirements.txt
py -m playwright install
```

## Run

```powershell
py main.py
```

## Example Test

An example Playwright pytest case is included at [tests/test_playwright_example.py](</C:/Users/LQ/PycharmProjects/custom_playwright debugger_for_pytest/tests/test_playwright_example.py:1>). It opens Chromium, goes to Google, and runs a real search query.

A longer, self-contained workflow example is included at [tests/test_playwright_long_example.py](</C:/Users/LQ/PycharmProjects/custom_playwright debugger_for_pytest/tests/test_playwright_long_example.py:1>).

```powershell
py -m pytest tests/test_playwright_example.py -vv
py -m pytest tests/test_playwright_long_example.py -vv
```

## Notes

- Test discovery uses `pytest --collect-only`.
- Test execution runs through the same Python interpreter that launches the UI.
- `Inspector Mode` runs tests with `PWDEBUG=1`, which opens Playwright Inspector for live step-through debugging.
- Browser selection supports bundled Playwright Chromium plus installed Google Chrome and Microsoft Edge stable channels.
- Full browser artifact capture assumes your tests use Playwright directly or via `pytest-playwright`.
- The desktop app itself can start without Playwright browser binaries, but running browser-based Playwright tests or Inspector Mode requires installed Playwright browsers such as Chromium.
- Per-run outputs are written to `.pyplay-debug-runs/<timestamp>/`.
