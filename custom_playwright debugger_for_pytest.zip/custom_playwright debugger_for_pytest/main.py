from pyplay_debug_runner.ui import run


if __name__ == "__main__":
    raise SystemExit(run())
