from __future__ import annotations

import re

from playwright.sync_api import Page, expect


def test_google_search_in_chromium(page: Page) -> None:
    page.goto("https://www.google.com/ncr", wait_until="domcontentloaded")
    page.evaluate("console.log('PyPlay Google search example loaded')")

    consent_buttons = page.locator("button").filter(has_text=re.compile(r"accept all|i agree", re.IGNORECASE))
    if consent_buttons.count():
        consent_buttons.first.click()

    search_box = page.locator("textarea[name='q'], input[name='q']").first
    expect(search_box).to_be_visible()

    query = "Playwright Python"
    search_box.fill(query)
    search_box.press("Enter")

    page.wait_for_url(re.compile(r"https://www\\.google\\.[^/]+/search\\?"))
    expect(page).to_have_title(re.compile(r"Playwright Python", re.IGNORECASE))
    expect(page.locator("textarea[name='q'], input[name='q']").first).to_have_value(query)
    expect(page).to_have_url(re.compile(r"[?&]q=Playwright\\+Python"))
