from __future__ import annotations

from playwright.sync_api import Page, expect


def test_task_board_workflow(page: Page) -> None:
    page.set_content(
        """
        <!doctype html>
        <html lang="en">
        <head>
          <meta charset="utf-8" />
          <title>Task Board Demo</title>
          <style>
            :root {
              color-scheme: light;
              font-family: "Segoe UI", sans-serif;
            }
            body {
              margin: 0;
              background: linear-gradient(135deg, #f4f7fb 0%, #eef3f8 100%);
              color: #172638;
            }
            .app {
              max-width: 1100px;
              margin: 32px auto;
              padding: 24px;
            }
            .hero {
              display: grid;
              grid-template-columns: 1.4fr 1fr;
              gap: 20px;
              margin-bottom: 20px;
            }
            .panel {
              background: rgba(255, 255, 255, 0.9);
              border: 1px solid #d7e2ee;
              border-radius: 20px;
              padding: 20px;
              box-shadow: 0 14px 32px rgba(36, 69, 106, 0.08);
            }
            .title {
              margin: 0 0 10px;
              font-size: 30px;
              font-weight: 800;
            }
            .subtitle {
              margin: 0;
              color: #55657b;
              line-height: 1.5;
            }
            .stats {
              display: grid;
              grid-template-columns: repeat(3, 1fr);
              gap: 12px;
              margin-top: 18px;
            }
            .stat {
              background: #f8fbff;
              border-radius: 16px;
              padding: 14px;
            }
            .stat-label {
              font-size: 12px;
              text-transform: uppercase;
              letter-spacing: 0.08em;
              color: #607289;
            }
            .stat-value {
              margin-top: 8px;
              font-size: 28px;
              font-weight: 800;
            }
            .controls {
              display: grid;
              grid-template-columns: 2fr 1fr 1fr auto;
              gap: 12px;
              margin-bottom: 18px;
            }
            input,
            select,
            button,
            textarea {
              font: inherit;
            }
            input,
            select,
            textarea {
              width: 100%;
              border: 1px solid #cfd9e4;
              border-radius: 12px;
              padding: 12px 14px;
              box-sizing: border-box;
            }
            button {
              border: 0;
              border-radius: 12px;
              padding: 12px 18px;
              font-weight: 700;
              background: #1d6fd6;
              color: white;
              cursor: pointer;
            }
            button.secondary {
              background: #edf3fb;
              color: #173456;
            }
            .board {
              display: grid;
              grid-template-columns: 1.3fr 1fr;
              gap: 20px;
            }
            .toolbar {
              display: flex;
              justify-content: space-between;
              align-items: center;
              gap: 12px;
              margin-bottom: 16px;
            }
            .filters {
              display: flex;
              gap: 8px;
              flex-wrap: wrap;
            }
            .chip {
              border: 1px solid #cfd9e4;
              background: white;
              border-radius: 999px;
              padding: 8px 12px;
              font-size: 13px;
            }
            .chip.active {
              background: #e8f1ff;
              border-color: #7aa6e8;
              color: #1d4f91;
            }
            ul {
              list-style: none;
              padding: 0;
              margin: 0;
              display: grid;
              gap: 12px;
            }
            .task {
              border: 1px solid #d7e2ee;
              border-radius: 16px;
              padding: 16px;
              display: grid;
              gap: 10px;
              background: white;
            }
            .task header {
              display: flex;
              justify-content: space-between;
              gap: 12px;
              align-items: start;
            }
            .task h3 {
              margin: 0;
              font-size: 18px;
            }
            .meta {
              display: flex;
              gap: 8px;
              flex-wrap: wrap;
              color: #5f6f84;
              font-size: 13px;
            }
            .pill {
              background: #f4f7fb;
              border-radius: 999px;
              padding: 5px 10px;
            }
            .task button {
              padding: 8px 12px;
              font-size: 13px;
            }
            .done {
              opacity: 0.7;
            }
            .done h3 {
              text-decoration: line-through;
            }
            .detail-list {
              display: grid;
              gap: 12px;
              margin-top: 16px;
            }
            .detail-item {
              background: #f8fbff;
              border-radius: 14px;
              padding: 14px;
              border: 1px solid #dde7f2;
            }
            .empty {
              padding: 32px;
              text-align: center;
              color: #6a7d94;
              border: 1px dashed #c7d4e3;
              border-radius: 16px;
              background: #fbfdff;
            }
          </style>
        </head>
        <body>
          <main class="app">
            <section class="hero">
              <div class="panel">
                <h1 class="title">Release Readiness Board</h1>
                <p class="subtitle">
                  Track the last automation tasks before a release candidate ships.
                </p>
                <div class="stats">
                  <div class="stat">
                    <div class="stat-label">Total</div>
                    <div class="stat-value" id="total-count">0</div>
                  </div>
                  <div class="stat">
                    <div class="stat-label">Completed</div>
                    <div class="stat-value" id="done-count">0</div>
                  </div>
                  <div class="stat">
                    <div class="stat-label">High Priority</div>
                    <div class="stat-value" id="high-count">0</div>
                  </div>
                </div>
              </div>
              <div class="panel">
                <div class="controls">
                  <input id="task-title" placeholder="Add a task" />
                  <select id="task-priority">
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                  <input id="task-owner" placeholder="Owner" />
                  <button id="add-task" type="button">Add</button>
                </div>
                <textarea id="task-notes" rows="4" placeholder="Notes"></textarea>
              </div>
            </section>

            <section class="board">
              <div class="panel">
                <div class="toolbar">
                  <strong>Tasks</strong>
                  <div class="filters">
                    <button class="chip active" data-filter="all" type="button">All</button>
                    <button class="chip" data-filter="open" type="button">Open</button>
                    <button class="chip" data-filter="done" type="button">Done</button>
                    <button class="chip" data-filter="high" type="button">High Priority</button>
                  </div>
                </div>
                <ul id="task-list"></ul>
                <div id="empty-state" class="empty">No tasks yet. Add the first release check.</div>
              </div>

              <aside class="panel">
                <strong>Activity</strong>
                <div class="detail-list" id="activity-log"></div>
              </aside>
            </section>
          </main>

          <script>
            const tasks = [
              {
                title: "Validate smoke suite on chromium",
                priority: "High",
                owner: "Ari",
                notes: "Run the top 15 smoke tests with trace capture enabled.",
                done: false
              },
              {
                title: "Review failed checkout snapshots",
                priority: "Medium",
                owner: "Noa",
                notes: "Compare baseline and new screenshots for layout drift.",
                done: true
              }
            ];

            let activeFilter = "all";

            const taskList = document.getElementById("task-list");
            const emptyState = document.getElementById("empty-state");
            const activityLog = document.getElementById("activity-log");
            const titleInput = document.getElementById("task-title");
            const priorityInput = document.getElementById("task-priority");
            const ownerInput = document.getElementById("task-owner");
            const notesInput = document.getElementById("task-notes");

            function updateStats() {
              document.getElementById("total-count").textContent = String(tasks.length);
              document.getElementById("done-count").textContent = String(tasks.filter(task => task.done).length);
              document.getElementById("high-count").textContent = String(
                tasks.filter(task => task.priority === "High").length
              );
            }

            function addActivity(message) {
              const entry = document.createElement("div");
              entry.className = "detail-item";
              entry.textContent = message;
              activityLog.prepend(entry);
              console.log(message);
            }

            function visibleTasks() {
              if (activeFilter === "open") {
                return tasks.filter(task => !task.done);
              }
              if (activeFilter === "done") {
                return tasks.filter(task => task.done);
              }
              if (activeFilter === "high") {
                return tasks.filter(task => task.priority === "High");
              }
              return tasks;
            }

            function render() {
              const visible = visibleTasks();
              taskList.innerHTML = "";
              emptyState.style.display = visible.length ? "none" : "block";

              for (const [index, task] of visible.entries()) {
                const item = document.createElement("li");
                item.className = "task" + (task.done ? " done" : "");
                item.dataset.taskTitle = task.title;
                item.innerHTML = `
                  <header>
                    <div>
                      <h3>${task.title}</h3>
                      <div class="meta">
                        <span class="pill">Priority: ${task.priority}</span>
                        <span class="pill">Owner: ${task.owner}</span>
                      </div>
                    </div>
                    <button class="toggle-task" data-visible-index="${index}" type="button">
                      ${task.done ? "Reopen" : "Complete"}
                    </button>
                  </header>
                  <div>${task.notes}</div>
                `;
                taskList.appendChild(item);
              }

              updateStats();
            }

            document.getElementById("add-task").addEventListener("click", () => {
              const title = titleInput.value.trim();
              const owner = ownerInput.value.trim() || "Unassigned";
              const notes = notesInput.value.trim() || "No extra notes.";
              if (!title) {
                addActivity("Rejected an empty task title.");
                return;
              }
              tasks.push({
                title,
                priority: priorityInput.value,
                owner,
                notes,
                done: false
              });
              addActivity(`Added task: ${title}`);
              titleInput.value = "";
              ownerInput.value = "";
              notesInput.value = "";
              priorityInput.value = "Low";
              render();
            });

            document.querySelectorAll("[data-filter]").forEach(button => {
              button.addEventListener("click", () => {
                activeFilter = button.dataset.filter;
                document.querySelectorAll("[data-filter]").forEach(chip => chip.classList.remove("active"));
                button.classList.add("active");
                addActivity(`Switched filter to ${activeFilter}.`);
                render();
              });
            });

            taskList.addEventListener("click", event => {
              const target = event.target;
              if (!(target instanceof HTMLElement) || !target.classList.contains("toggle-task")) {
                return;
              }
              const visible = visibleTasks();
              const index = Number(target.dataset.visibleIndex);
              const task = visible[index];
              const original = tasks.find(item => item.title === task.title);
              if (!original) {
                return;
              }
              original.done = !original.done;
              addActivity(`${original.done ? "Completed" : "Reopened"} task: ${original.title}`);
              render();
            });

            addActivity("Board initialized with seeded release tasks.");
            render();
          </script>
        </body>
        </html>
        """
    )

    expect(page.get_by_role("heading", name="Release Readiness Board")).to_be_visible()
    expect(page.locator("#total-count")).to_have_text("2")
    expect(page.locator("#done-count")).to_have_text("1")
    expect(page.locator("#high-count")).to_have_text("1")

    page.get_by_placeholder("Add a task").fill("Investigate flaky firefox auth redirect")
    page.get_by_placeholder("Owner").fill("Mina")
    page.locator("#task-priority").select_option("High")
    page.locator("#task-notes").fill("Collect a trace and console logs before triage.")
    page.get_by_role("button", name="Add").click()

    expect(page.locator("#total-count")).to_have_text("3")
    expect(page.locator("#high-count")).to_have_text("2")
    expect(page.locator("#activity-log .detail-item").first).to_have_text(
        "Added task: Investigate flaky firefox auth redirect"
    )

    high_priority_chip = page.get_by_role("button", name="High Priority")
    high_priority_chip.click()
    expect(page.locator("#task-list .task")).to_have_count(2)
    expect(page.locator("#task-list .task").first).to_contain_text("Validate smoke suite on chromium")
    expect(page.locator("#task-list .task").nth(1)).to_contain_text("Investigate flaky firefox auth redirect")

    page.locator("#task-list .task", has_text="Validate smoke suite on chromium").get_by_role(
        "button", name="Complete"
    ).click()
    expect(page.locator("#done-count")).to_have_text("2")
    expect(page.locator("#activity-log .detail-item").first).to_have_text(
        "Completed task: Validate smoke suite on chromium"
    )

    page.get_by_role("button", name="Done").click()
    expect(page.locator("#task-list .task")).to_have_count(2)
    expect(page.locator("#task-list .task").first).to_have_class(r".*done.*")
    expect(page.locator("#task-list .task").first).to_contain_text("Validate smoke suite on chromium")

    page.get_by_role("button", name="Open").click()
    expect(page.locator("#task-list .task")).to_have_count(1)
    expect(page.locator("#task-list .task").first).to_contain_text("Investigate flaky firefox auth redirect")

    activity_items = page.locator("#activity-log .detail-item")
    expect(activity_items).to_have_count(6)
